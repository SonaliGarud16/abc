/*********************************************************
 * Copyright (C) 2012-2015 VMware, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation version 2 and no later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *
 *********************************************************/

/*
 * scsi_defs.h
 *
 * General SCSI definitions
 */

#ifndef _SCSI_DEFS_H_
#define _SCSI_DEFS_H_

#define INCLUDE_ALLOW_USERLEVEL

#define INCLUDE_ALLOW_MODULE
#define INCLUDE_ALLOW_VMK_MODULE
#define INCLUDE_ALLOW_VMKERNEL
#define INCLUDE_ALLOW_DISTRIBUTE
#include "includeCheck.h"

#include "vm_basic_defs.h"  // for offsetof()

#define SCSI_MIN_CMD_LEN   6
#define SCSI_MAX_CMD_LEN   16
#define SCSI_SENSE_HDR_LEN 8
/*
 * Non-exhaustive list of SCSI operation codes.  Note that
 * some codes are defined differently according to the target
 * device.  Also, codes may have slightly different meanings
 * and/or names based on the version of the SCSI spec.
 *
 * NB: Command descriptions come from the "SCSI Book" and not
 *     from the SCSI specifications (YMMV).
 */
#define SCSI_CMD_TEST_UNIT_READY       0x00  // test if LUN ready to accept a command
#define SCSI_CMD_REZERO_UNIT           0x01  // seek to track 0
#define SCSI_CMD_REQUEST_SENSE         0x03  // return detailed error information
#define SCSI_CMD_FORMAT_UNIT           0x04  //
#define SCSI_CMD_READ_BLOCKLIMITS      0x05  //
#define SCSI_CMD_REASSIGN_BLOCKS       0x07  //
#define SCSI_CMD_INIT_ELEMENT_STATUS   0x07  // Media changer
#define SCSI_CMD_READ6                 0x08  // read w/ limited addressing
#define SCSI_CMD_WRITE6                0x0a  // write w/ limited addressing
#define SCSI_CMD_PRINT                 0x0a  // print data
#define SCSI_CMD_SEEK6                 0x0b  // seek to LBN
#define SCSI_CMD_SLEW_AND_PRINT        0x0b  // advance and print
#define SCSI_CMD_READ_REVERSE          0x0f  // read backwards
#define SCSI_CMD_WRITE_FILEMARKS       0x10  //
#define SCSI_CMD_SYNC_BUFFER           0x10  // print contents of buffer
#define SCSI_CMD_SPACE                 0x11  //
#define SCSI_CMD_INQUIRY               0x12  // return LUN-specific information
#define SCSI_CMD_RECOVER_BUFFERED      0x14  // recover buffered data
#define SCSI_CMD_MODE_SELECT           0x15  // set device parameters
#define SCSI_CMD_RESERVE_UNIT          0x16  // make LUN accessible only to certain initiators
#define SCSI_CMD_RELEASE_UNIT          0x17  // make LUN accessible to other initiators
#define SCSI_CMD_COPY                  0x18  // autonomous copy from/to another device
#define SCSI_CMD_ERASE                 0x19  //
#define SCSI_CMD_MODE_SENSE            0x1a  // read device parameters
#define SCSI_CMD_START_UNIT            0x1b  // start or stop unit
#define SCSI_CMD_SCAN                  0x1b  // perform scan
#define SCSI_CMD_STOP_PRINT            0x1b  // interrupt printing
#define SCSI_CMD_RECV_DIAGNOSTIC       0x1c  // read self-test results
#define SCSI_CMD_SEND_DIAGNOSTIC       0x1d  // initiate self-test
#define SCSI_CMD_MEDIUM_REMOVAL        0x1e  // lock/unlock door
#define SCSI_CMD_READ_FORMAT_CAPACITIES 0x23 // read format capacities
#define SCSI_CMD_SET_WINDOW            0x24  // set scanning window
#define SCSI_CMD_GET_WINDOW            0x25  // get scanning window
#define SCSI_CMD_READ_CAPACITY         0x25  // read number of logical blocks
#define SCSI_CMD_READ10                0x28  // read
#define SCSI_CMD_READ_GENERATION       0x29  // read max generation address of LBN
#define SCSI_CMD_WRITE10               0x2a  // write
#define SCSI_CMD_SEEK10                0x2b  // seek LBN
#define SCSI_CMD_POSITION_TO_ELEMENT   0x2b  // media changer
#define SCSI_CMD_ERASE10               0x2c  //
#define SCSI_CMD_READ_UPDATED_BLOCK    0x2d  // read specific version of changed block
#define SCSI_CMD_WRITE_VERIFY          0x2e  // write w/ verify of success
#define SCSI_CMD_VERIFY                0x2f  // verify success
#define SCSI_CMD_SEARCH_DATA_HIGH      0x30  // search for data pattern
#define SCSI_CMD_SEARCH_DATA_EQUAL     0x31  // search for data pattern
#define SCSI_CMD_SEARCH_DATA_LOW       0x32  // search for data pattern
#define SCSI_CMD_SET_LIMITS            0x33  // define logical block boundaries
#define SCSI_CMD_PREFETCH              0x34  // read data into buffer
#define SCSI_CMD_READ_POSITION         0x34  // read current tape position
#define SCSI_CMD_SYNC_CACHE            0x35  // re-read data into buffer
#define SCSI_CMD_LOCKUNLOCK_CACHE      0x36  // lock/unlock data in cache
#define SCSI_CMD_READ_DEFECT_DATA      0x37  //
#define SCSI_CMD_MEDIUM_SCAN           0x38  // search for free area
#define SCSI_CMD_COMPARE               0x39  // compare data
#define SCSI_CMD_COPY_VERIFY           0x3a  // autonomous copy w/ verify
#define SCSI_CMD_WRITE_BUFFER          0x3b  // write data buffer
#define SCSI_CMD_READ_BUFFER           0x3c  // read data buffer
#define SCSI_CMD_UPDATE_BLOCK          0x3d  // substitute block with an updated one
#define SCSI_CMD_READ_LONG             0x3e  // read data and ECC
#define SCSI_CMD_WRITE_LONG            0x3f  // write data and ECC
#define SCSI_CMD_CHANGE_DEF            0x40  // set SCSI version
#define SCSI_CMD_WRITE_SAME            0x41  //
#define SCSI_CMD_READ_SUBCHANNEL       0x42  // read subchannel data and status
#define SCSI_CMD_UNMAP                 0x42  // unmap blocks on TP devices
#define SCSI_CMD_READ_TOC              0x43  // read contents table
#define SCSI_CMD_READ_HEADER           0x44  // read LBN header
#define SCSI_CMD_PLAY_AUDIO10          0x45  // audio playback
#define SCSI_CMD_GET_CONFIGURATION     0x46  // get configuration (SCSI-3)
#define SCSI_CMD_PLAY_AUDIO_MSF        0x47  // audio playback starting at MSF address
#define SCSI_CMD_PLAY_AUDIO_TRACK      0x48  // audio playback starting at track/index
#define SCSI_CMD_PLAY_AUDIO_RELATIVE   0x49  // audio playback starting at relative track
#define SCSI_CMD_GET_EVENT_STATUS_NOTIFICATION 0x4a //
#define SCSI_CMD_PAUSE                 0x4b  // audio playback pause/resume
#define SCSI_CMD_LOG_SELECT            0x4c  // select statistics
#define SCSI_CMD_LOG_SENSE             0x4d  // read statistics
#define SCSI_CMD_STOP_PLAY             0x4e  // audio playback stop
#define SCSI_CMD_READ_DISC_INFO        0x51  // info on CDRs
#define SCSI_CMD_READ_TRACK_INFO       0x52  // track info on CDRs
#define SCSI_CMD_RESERVE_TRACK         0x53  // leave space for data on CDRs
#define SCSI_CMD_SEND_OPC_INFORMATION  0x54  // Optimum Power Calibration
#define SCSI_CMD_MODE_SELECT10         0x55  // set device parameters
#define SCSI_CMD_RESERVE_UNIT10        0x56  //
#define SCSI_CMD_RELEASE_UNIT10        0x57  //
#define SCSI_CMD_REPAIR_TRACK          0x58  //
#define SCSI_CMD_MODE_SENSE10          0x5a  // read device parameters
#define SCSI_CMD_CLOSE_SESSION         0x5b  // close area/sesssion (recordable)
#define SCSI_CMD_READ_BUFFER_CAPACITY  0x5c  // CDR burning info.
#define SCSI_CMD_SEND_CUE_SHEET        0x5d  // (CDR Related?)
#define SCSI_CMD_PERSISTENT_RESERVE_IN 0x5e  //
#define SCSI_CMD_PERSISTENT_RESERVE_OUT 0x5f //
#define SCSI_CMD_XDWRITE_EXTENDED      0x80  //
#define SCSI_CMD_REBUILD               0x81  //
#define SCSI_CMD_REGENERATE            0x82  //
#define SCSI_CMD_EXTENDED_COPY         0x83  // extended copy
#define SCSI_CMD_RECEIVE_COPY_RESULTS  0x84  // receive copy results
#define SCSI_CMD_READ16                0x88  // read data
#define SCSI_ATS_OPCODE                0x89  // ATS
#define SCSI_CMD_WRITE16               0x8a  // write data
#define SCSI_CMD_ORWRITE16             0x8b  //
#define SCSI_CMD_READ_ATTRIBUTE        0x8c  // read attribute
#define SCSI_CMD_WRITE_ATTRIBUTE       0x8d  // write attribute
#define SCSI_CMD_WRITE_VERIFY16        0x8e  //
#define SCSI_CMD_VERIFY16              0x8f  //
#define SCSI_CMD_PREFETCH16            0x90  //
#define SCSI_CMD_SYNC_CACHE16          0x91  //
#define SCSI_CMD_WRITE_SAME16          0x93  //
#define SCSI_CMD_SERVICE_ACTION_IN     0x9e  // service action in
#define SCSI_CMD_SERVICE_ACTION_OUT    0x9f  // service action out
#define SCSI_CMD_REPORT_LUNS           0xa0  //
#define SCSI_CMD_BLANK                 0xa1  // erase RW media
#define SCSI_CMD_SECURITY_PROTOCOL_IN  0xa2  //
#define SCSI_CMD_MAINTENANCE_IN        0xa3  // service actions define reports
#define SCSI_CMD_MAINTENANCE_OUT       0xa4  // service actions define changes
#define SCSI_CMD_SEND_KEY              0xa3  //
#define SCSI_CMD_REPORT_KEY            0xa4  // report key (SCSI-3)
#define SCSI_CMD_MOVE_MEDIUM           0xa5  //
#define SCSI_CMD_PLAY_AUDIO12          0xa5  // audio playback
#define SCSI_CMD_EXCHANGE_MEDIUM       0xa6  //
#define SCSI_CMD_LOADCD                0xa6  //
#define SCSI_CMD_SET_READ_AHEAD        0xa7  //
#define SCSI_CMD_READ12                0xa8  // read (SCSI-3)
#define SCSI_CMD_PLAY_TRACK_RELATIVE   0xa9  // audio playback starting at relative track
#define SCSI_CMD_WRITE12               0xaa  // write data
#define SCSI_CMD_READ_MEDIA_SERIAL_NUMBER 0xab //
#define SCSI_CMD_ERASE12               0xac  // erase logical block
#define SCSI_CMD_GET_PERFORMANCE       0xac  //
#define SCSI_CMD_READ_DVD_STRUCTURE    0xad  // read DVD structure (SCSI-3)
#define SCSI_CMD_WRITE_VERIFY12        0xae  // write logical block, verify success
#define SCSI_CMD_VERIFY12              0xaf  // verify data
#define SCSI_CMD_SEARCH_DATA_HIGH12    0xb0  // search data pattern
#define SCSI_CMD_SEARCH_DATA_EQUAL12   0xb1  // search data pattern
#define SCSI_CMD_SEARCH_DATA_LOW12     0xb2  // search data pattern
#define SCSI_CMD_SET_LIMITS12          0xb3  // set block limits
#define SCSI_CMD_REQUEST_VOLUME_ELEMENT_ADDR 0xb5 //
#define SCSI_CMD_SECURITY_PROTOCOL_OUT 0xb5  //
#define SCSI_CMD_SEND_VOLUME_TAG       0xb6  //
#define SCSI_CMD_SET_STREAMING         0xb6  // For avoiding over/underrun
#define SCSI_CMD_READ_DEFECT_DATA12    0xb7  // read defect data information
#define SCSI_CMD_READ_ELEMENT_STATUS   0xb8  // read element status
#define SCSI_CMD_SELECT_CDROM_SPEED    0xb8  // set data rate
#define SCSI_CMD_READ_CD_MSF           0xb9  // read CD information (all formats, MSF addresses)
#define SCSI_CMD_AUDIO_SCAN            0xba  // fast audio playback
#define SCSI_CMD_SET_CDROM_SPEED       0xbb  // (proposed)
#define SCSI_CMD_SEND_CDROM_XA_DATA    0xbc  //
#define SCSI_CMD_PLAY_CD               0xbc  //
#define SCSI_CMD_MECH_STATUS           0xbd  //
#define SCSI_CMD_READ_CD               0xbe  // read CD information (all formats, MSF addresses)
#define SCSI_CMD_SEND_DVD_STRUCTURE    0xbf  // burning DVDs?

/*
 * Fujitsu scanners use 0xC1/0xC2 commands.
 * See libsane for details.
 */
#define SCSI_CMD_VENDOR_FUJITSU_OUT    0xc1
#define SCSI_CMD_VENDOR_FUJITSU_IN     0xc2

/*
 * A workaround for a specific scanner (NIKON LS-2000).
 */
#define SCSI_CMD_VENDOR_NIKON_UNKNOWN  0xe1

/*
 * Secondary op-codes for SCSI commands Service Action In (SAI) and Out (SAO)
 */
#define SCSI_CMD_SAI_READ_CAPACITY16   0x10  // SAI: read number of logical blks

/*
 * Sense key codes
 */
#define SCSI_SENSE_KEY_NONE            0x0   // there is no sense information
#define SCSI_SENSE_KEY_RECOVERED_ERROR 0x1   // the last command completed succesfully but used error correction in the process
#define SCSI_SENSE_KEY_NOT_READY       0x2   // the addressed LUN is not ready to be accessed
#define SCSI_SENSE_KEY_MEDIUM_ERROR    0x3   // the target detected a data error on the medium
#define SCSI_SENSE_KEY_HARDWARE_ERROR  0x4   // the target detected a hardware error during a command or self-test
#define SCSI_SENSE_KEY_ILLEGAL_REQUEST 0x5   // either the command or the parameter list contains an error
#define SCSI_SENSE_KEY_UNIT_ATTENTION  0x6   // the LUN has been reset (bus reset of medium change)
#define SCSI_SENSE_KEY_DATA_PROTECT    0x7   // access to the data is blocked
#define SCSI_SENSE_KEY_BLANK_CHECK     0x8   // reached an unexpected written or unwritten region of the medium
#define SCSI_SENSE_KEY_VENDOR_SPECIFIC 0x9   // report vendor specific condition
#define SCSI_SENSE_KEY_COPY_ABORTED    0xa   // COPY, COMPARE, or COPY AND VERIFY was aborted
#define SCSI_SENSE_KEY_ABORTED_CMD     0xb   // the target aborted the command
#define SCSI_SENSE_KEY_EQUAL           0xc   // comparison for SEARCH DATA was unsuccessful
#define SCSI_SENSE_KEY_VOLUME_OVERFLOW 0xd   // the medium is full
#define SCSI_SENSE_KEY_MISCOMPARE      0xe   // source and data on the medium do not agree
#define SCSI_SENSE_KEY_COMPLETED       0xf   // command completed with valid sense information

/**
 * \brief Descriptor Type field
 * SPC 4 r37, Section 4.5.2.1 table 38
 */
#define SCSI_SENSE_DESCRIPTOR_TYPE_INFO                           0x0
#define SCSI_SENSE_DESCRIPTOR_TYPE_COMMAND_SPECIFIC_INFORMATION   0x1
#define SCSI_SENSE_DESCRIPTOR_TYPE_SENSEKEY_SPECIFIC              0x2
#define SCSI_SENSE_DESCRIPTOR_TYPE_FIELD_REPLACABLE_UNIT          0x3
#define SCSI_SENSE_DESCRIPTOR_TYPE_BLOCKS_COMMANDS                0x5
#define SCSI_SENSE_DESCRIPTOR_TYPE_ATA_STS_RETURN                 0x9
#define SCSI_SENSE_DESCRIPTOR_TYPE_FORWARDED_SENSE                0xc
#define SCSI_SENSE_DESCRIPTOR_TYPE_DABD                           0xd

/*
 * The Additional Sense Code - ASC
 * and Additional Sense Code Qualifiers - ASCQ
 * always come in pairs.
 *
 * Note:
 *     These values are found at senseBuffer[12] and senseBuffer[13].
 *     These values are found at senseBuffer[12] and senseBuffer[13] for
 *     'fixed' format sense data and senseBuffer[2] and senseBuffer[3] for
 *     'descriptor' format sense data. See spc4r37 section 4.5 "Sense data"
 *     for more information.
 *     
 *     You may see references to these in legacy code. New code should make an
 *     attempt to use the ASC/ASCQ syntax.
 *
 *     While not an exhastive list, the codes here will conform to spc4r37
 *     Annex F.2 Additional sense codes. ASCQ codes are indented from their
 *     corresponding ASC codes for clarity.
 */
#define SCSI_ASC_NO_ADDITIONAL_SENSE                           0x00  // No additional sense info
#define SCSI_ASC_LU_NOT_READY                                  0x04  // logical unit not ready
#define SCSI_ASC_LU_NOT_READY_ASCQ_UNIT_BECOMING_READY            0x01
#define SCSI_ASC_LU_NOT_READY_ASCQ_INIT_CMD_REQUIRED              0x02  // initializing command required
#define SCSI_ASC_LU_NOT_READY_ASCQ_FORMAT_IN_PROGRESS             0x04
#define SCSI_ASC_LU_NOT_READY_ASCQ_MANUAL_INTERVENTION_REQUIRED   0x03
#define SCSI_ASC_LU_NOT_READY_ASCQ_TARGET_PORT_IN_TRANSITION      0x0a  // an ascq
#define SCSI_ASC_LU_NOT_READY_ASCQ_TARGET_PORT_IN_STANDBY_MODE    0x0b  // an ascq
#define SCSI_ASC_COPY_FAILED                                   0x0d
#define SCSI_ASC_COPY_FAILED_ASCQ_THIRD_PARTY_DEVICE_FAILURE      0x01
#define SCSI_ASC_COPY_FAILED_ASCQ_UNREACHABLE                     0x02
#define SCSI_ASC_COPY_FAILED_ASCQ_INCORRECT_TARGET_DEVICE_TYPE    0x03
#define SCSI_ASC_COPY_FAILED_ASCQ_TARGET_DEVICE_DATA_UNDERRUN     0x04
#define SCSI_ASC_COPY_FAILED_ASCQ_TARGET_DEVICE_DATA_OVERRUN      0x05
#define SCSI_ASC_LU_NOT_READY_ASCQ_SPACE_ALLOCATION_IN_PROGRESS   0x14  // an ascq
#define SCSI_ASC_LU_NO_RESPONSE_TO_SELECTION                   0x05  // logical unit doesn't respond to selection
#define SCSI_ASC_NO_REFERENCE_POSITION_FOUND                   0x06
#define SCSI_ASC_WARNING                                       0x0b
#define SCSI_ASC_WRITE_ERROR                                   0x0c  // Write error
#define SCSI_ASC_UNRECOVERED_READ_ERROR                        0x11  // Unrecovered read error
#define SCSI_ASC_PARAM_LIST_LENGTH_ERROR                       0x1a  // parameter list length error
#define SCSI_ASC_RECOVERED_DATA                                0x17
#define SCSI_ASC_INVALID_COMMAND_OPERATION                     0x20  // invalid command operation code
#define SCSI_ASC_LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE            0x21  // Invalid LBA
#define SCSI_ASC_INVALID_FIELD_IN_CDB                          0x24
#define SCSI_ASC_LU_NOT_SUPPORTED                              0x25  // LU has been removed
#define SCSI_ASC_INVALID_FIELD_IN_PARAMETER_LIST               0x26
#define SCSI_ASC_WRITE_PROTECTED                               0x27  // device is write protected
// Thin provisioning extention 07/27/07 approved in spc4r20a
#define SCSI_ASC_WRITE_PROTECTED_ASCQ_SPACE_ALLOCATION_FAILED     0x07  // an ascq
#define SCSI_ASC_MEDIUM_MAY_HAVE_CHANGED                       0x28  // after changing medium
#define SCSI_ASC_POWER_ON_OR_RESET                             0x29  // device power-on or SCSI reset
#define SCSI_ASC_PARAMS_CHANGED                                0x2a
#define SCSI_ASC_PARAMS_CHANGED_ASCQ_RESERVATIONS_PREEMPTED       0x03
#define SCSI_ASC_PARAMS_CHANGED_ASCQ_RESERVATIONS_RELEASED        0x04
#define SCSI_ASC_PARAMS_CHANGED_ASCQ_REGISTRATIONS_PREEMPTED      0x05
#define SCSI_ASC_INCOMPATIBLE_MEDIUM                           0x30  // Generic bad medium error
#define SCSI_ASC_MEDIUM_FORMAT_CORRUPTED                       0x31
#define SCSI_ASC_MEDIUM_FORMAT_CORRUPTED_ASCQ_FORMAT_FAILED       0x01
#define SCSI_ASC_EVENT_STATUS_NOTIFICATION                     0x38 // event status notification
#define SCSI_ASC_EVENT_STATUS_NOT_ASCQ_TP_SOFT_THRESHOLD_REACHED   0x07 // ascq
#define SCSI_ASC_SAVING_PARAMS_NOT_SUPPORTED                   0x39  // Saving parameters not supported
#define SCSI_ASC_MEDIUM_NOT_PRESENT                            0x3a  // changing medium
#define SCSI_ASC_MEDIUM_NOT_PRESENT_ASCQ_TRAY_OPEN                 0x02  // an ascq
#define SCSI_ASC_INVALID_MESSAGE_ERROR                         0x49
#define SCSI_ASC_COMMAND_PHASE_ERROR                           0x4a
#define SCSI_ASC_DATA_PHASE_ERROR                              0x4b
#define SCSI_ASC_MEDIUM_REMOVAL_FAILED                         0x53  // w/ 0x4 it is failed, 0x5 is prevented
#define SCSI_ASCQ_MEDIUM_REMOVAL_PREVENTED                         0x02
#define SCSI_ASC_INSUFFICIENT_REGISTRATION_RESOURCES           0x55  // during persistent reservations
#define SCSI_ASCQ_INSUFFICIENT_REGISTRATION_RESOURCES              0x04
#define SCSI_ASCQ_ASYMMETRIC_ACCESS_STATE_CHANGED                  0x06
#define SCSI_ASCQ_TARGET_PORT_IN_STANDBY_STATE                     0x0b
#define SCSI_ASCQ_TARGET_PORT_IN_UNAVAILABLE_STATE                 0x0c
#define SCSI_ASC_IMPENDING_FAILURE                             0x5d
#define SCSI_ASC_INVALID_MODE_FOR_THIS_TRACK                   0x64
#define SCSI_ASC_ATA_DEVICE_FEATURE_NOT_ENABLED                0x67
#define SCSI_ASCQ_ATA_DEVICE_FEATURE_NOT_ENABLED                   0x0b

/*
 * ATS Miscompare ASC/ASQ. Defined in SPC-3 r23
 */
#define SCSI_ASC_MISCOMPARE           0x1d
#define SCSI_ASC_MISCOMPARE_ASCQ          0x00

/*
 * VVol uses the below ASC/ASCQs - 4/0x1D and 0x68/1. Refer SPC4 r37
 */
#define SCSI_ASC_LU_NOT_READY_ASCQ_CONFIGURATION_IN_PROGRESS             0x1D
#define SCSI_ASC_LU_NOT_CONFIGURED_ASCQ_SUBSID_LU_NOT_CONFIGURED         0x01

#define SCSI_TAG_ENABLE 0x20                    // Set to indicate tag is valid
#define SCSI_TAG_SIMPLE (SCSI_TAG_ENABLE|0x0)   // No constraint
#define SCSI_TAG_HEAD   (SCSI_TAG_ENABLE|0x1)   // Always first
#define SCSI_TAG_ORDER  (SCSI_TAG_ENABLE|0x2)   // Syncronizing

#define SCSI_CMD_START_UNIT_START_BIT 0x01   // Value of Start bit for SCSI_CMD_START_UNIT

/*
 * SCSI Command Data Blocks (CDBs) come in at least four flavors:
 *
 * 1. 6-byte commands were originally spec'd and limit the addressable
 *    storage to 1GByte (21 bits x 512 bytes/logical block).
 * 2. 10-byte commands first appeared in SCSI-2; they have a 32-bit
 *    logical block number range but transfers are limited to 64KB.
 * 3. 12-byte commands also appeared in SCSI-2; they differ mainly
 *    int that large amounts of data may be transferred (32-bit data length).
 * 4. 16-byte commands were added in SCSI-3; they have additional space
 *    for unspecified command data.
 *
 * We do not support 16-byte CDB's, only 6-, 10-, and 12-byte versions.
 */
typedef struct {
   uint8    opcode;     // operation code
   uint8    lbnhi:5,    // top 5 bits of logical block number
            lun:3;      // logical unit number
   uint16   lbnlo;      // bottom 16 bits of logical block number
   uint8    length;     // data length
   uint8    control;    // control byte
} SCSICDB6;

typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;
   uint8       :5,
            lun:3;
   uint32   lbn;
   uint8    reserved;
   uint16   length;
   uint8    control;
}
#include "vmware_pack_end.h"
SCSICDB10;
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;
   uint8       :5,
            lun:3;
   uint32   lbn;
   uint32   length;
   uint8    reserved;
   uint8    control;
}
#include "vmware_pack_end.h"
SCSICDB12;

/*
 * Format of INQUIRY request and response blocks.
 * These are defined here because many SCSI devices
 * need them.
 * SCSI 2 Only - See ANSI X3.131-199x Section 8.2.5 Table 44
 */
typedef struct {
   uint8 opcode;           // INQUIRY (0x12)
   uint8 evpd  :1,         // enhanced vital product data
         cmddt :1,         // command support data (new in SCSI-3)
         resv12:3,
         lun   :3;
   uint8 pagecode;         // only valid when cmddt or evdp is set
   uint8 reserved;
   uint8 length;
   uint8 control;
} SCSIInquiryCmd;

/*
 * Format of the SCSI-3 INQUIRY command as defined in:
 *   SPC-3 - spc3r23, section 6.4.1 table 80
 *   SPC-4 - spc4r37, Section 6.6.1 table 175
 */
typedef struct {
   uint8 opcode;           // INQUIRY (0x12)
   uint8 evpd  :1,         // Enhanced Vital Product Data
         obslt :1,         // Obsolete as per SPC-3
         resv  :6;         // The remaining bits are all RESERVED
   uint8 pagecode;         // Only valid when evpd is set
   uint8 lengthMSB;        // The SPC-3 spec has a 2 byte len field
   uint8 length;
   uint8 control;
} SCSI3InquiryCmd;

/*
 * SCSI Inquiry data
 * SCSI2/SCSI3 - OBSOLETE (Note: mixed SCSI2 and SCSI3 not compatible)
 *               Use SCSIInquiry36Response or SCSI3InquiryResponse instead.
 */
typedef struct {
   uint8 devclass    :5,   // SCSI device class
         pqual       :3;   // peripheral qualifier
   uint8             :6,   // reserved for SCSI-1
         lu_cong     :1,   // 1 means its part of a conglomerate
                           // (from t10 13-020r1; expected to be in SPC4 soon)
                           // (Refer to SAM5r14 for conglomerate info)
         rmb         :1;   // removable bit
   uint8 ansi        :3,   // ANSI version
         ecma        :3,   // ECMA version (Obsolete)
         iso         :2;   // ISO version (Obsolete)
   uint8 dataformat  :4,   // format of the following standard data
                     :1,
         naca        :1,
         tio         :1,   // device supports TERMINATE I/O PROCESS message
         aen         :1;   // asynchronous event notification capability
   uint8 optlen;           // length of additional data that follows
   uint8             :4,
         tpgs        :2,   // Target Portal Group Support
                     :2;
   uint8 adr16       :1,   // device supports 16-bit wide SCSI addresses
         adr32       :1,   // device supports 32-bit wide SCSI addresses
         arq         :1,
         mchngr      :1,   // device has attached media changer (SCSI-3)
         dualp       :1,   // device is dual-ported (SCSI-3)
         port        :1,   // port A or port B when dual-ported (SCSI-3)
                     :2;
   uint8 sftr        :1,   // device supports soft reset capability
         que         :1,   // device supports tagged commands
         trndis      :1,   // device supports transfer disable messages (SCSI-3)
         link        :1,   // device supports linked commands
         sync        :1,   // device supports synchronous transfers
         w16         :1,   // device supports 16-bit wide SCSI data transfers
         w32         :1,   // device supports 32-bit wide SCSI data transfers
         rel         :1;   // device supports relative addressing
   uint8 manufacturer[8];  // manufacturer's name in ascii
#define SCSI_VENDOR_SZ sizeof(((SCSIInquiryResponse *) 0)->manufacturer)
   uint8 product[16];      // product name in ascii
#define SCSI_MODEL_SZ sizeof(((SCSIInquiryResponse *) 0)->product)
   uint8 revision[4];      // product version number in ascii
   uint8 vendor1[20];      // vendor unique data (opaque)
   uint8 reserved[40];
} SCSIInquiryResponse;     // standard INQUIRY response format

/*
 * Format of standard SCSI3 INQUIRY response block.
 * See spc4r37, Section 6.6.2 table 176
 *
 * Not the same as SCSIInquiryResponse above. Updated to spc4r37.
 *
 * Note: Two fields are used for compatibility between SCSI2 and SPC-4
 *       when VSCSI creates an Inquiry response for VMs. The reason for this
 *       is when creating a SCSI2 response, we use the same SPC-4 Inquiry
 *       response block. For SCSI2 the wbus32 and sftr fields must be set so
 *       the guest properly handles SCSI2 at the fastest speed possible.
 *
 *         SPC-4                       SCSI2
 *
 *       wbus32 (reserved) = 0     wbus32 (wbus32) = 1
 *       vs2 (vendor bit)  = 0     vs2 (sftr)      = 1
 *
 */
typedef struct {
   uint8 devclass    :5,   // SCSI device class
#define SCSI_CLASS_DISK    0x00      // disk drive
#define SCSI_CLASS_TAPE    0x01      // tape drive
#define SCSI_CLASS_PRINTER 0x02      // printer
#define SCSI_CLASS_CPU     0x03      // processor device
#define SCSI_CLASS_WORM    0x04      // WORM drive
#define SCSI_CLASS_CDROM   0x05      // CD-ROM drive
#define SCSI_CLASS_SCANNER 0x06      // scanner (obsolete)
#define SCSI_CLASS_OPTICAL 0x07      // optical disk
#define SCSI_CLASS_MEDIA   0x08      // media changer
#define SCSI_CLASS_COM     0x09      // communication device (obsolete)
#define SCSI_CLASS_RAID    0x0c      // RAID controller (SCSI-3, reserved in SCSI-2)
#define SCSI_CLASS_SES     0x0d      // SCSI Enclosure Services device (t10 SES)
#define SCSI_CLASS_SIMPLE_DISK 0x0e  // Simplified direct-access device (e.g., magnetic disk)
#define SCSI_CLASS_OCRW    0x0f      // Optical card reader/writer device
#define SCSI_CLASS_OSD     0x11      // Object-based Storage Device
#define SCSI_CLASS_ADC     0x12      // Automation/Drive Interface
#define SCSI_CLASS_UNKNOWN 0x1f      // unknown device
         pqual       :3;   // peripheral qualifier
#define SCSI_PQUAL_CONNECTED     0  // device described is connected to the LUN
#define SCSI_PQUAL_NOTCONNECTED  1  // target supports such a device, but none is connected
#define SCSI_PQUAL_NODEVICE      3  // target does not support a physical device for this LUN
   uint8             :6,   // reserved for SCSI-1/2
         lu_cong     :1,   // logical unit conglomerate (see SAM-5)
         rmb         :1;   // removable bit
   uint8 version;          // SPC SCSI Version
                           // Note: ansi version dropped in SPC-2
#define SCSI_ANSI_SCSI1      0x00   // device supports SCSI-1 (Obsolete)
#define SCSI_ANSI_CCS        0x01   // device supports the CCS (Obsolete)
#define SCSI_ANSI_SCSI2      0x02   // device supports SCSI-2 (Obsolete)
#define SCSI_ANSI_SCSI3_SPC  0x03   // device supports SCSI-3 version SPC
#define SCSI_ANSI_SCSI3_SPC2 0x04   // device supports SCSI-3 version SPC-2
#define SCSI_ANSI_SCSI3_SPC3 0x05   // device supports SCSI-3 version SPC-3
#define SCSI_ANSI_SCSI3_SPC4 0x06   // device supports SCSI-3 version SPC-4
   uint8 dataformat  :4,   // response data format (always = 2)
         hisup       :1,   // historical support (old "hierarchical support")
         naca        :1,   // normal ACA support
                     :2;   // reserved
   uint8 optlen;           // length of additional data that follows
   uint8 protect     :1,   // protection support
                     :2,   // reserved
         tpc         :1,   // third party copy
         tpgs        :2,   // Target Portal Group Support
#define SCSI_TPGS_NONE                       0x0
#define SCSI_TPGS_IMPLICIT_ONLY              0x1
#define SCSI_TPGS_IMPLICIT                   SCSI_TPGS_IMPLICIT_ONLY
#define SCSI_TPGS_EXPLICIT_ONLY              0x2
#define SCSI_TPGS_EXPLICIT                   SCSI_TPGS_EXPLICIT_ONLY
#define SCSI_TPGS_BOTH_IMPLICIT_AND_EXPLICIT 0x3
#define SCSI_TPGS_BOTH                       SCSI_TPGS_BOTH_IMPLICIT_AND_EXPLICIT
         acc         :1,   // access controls coordinator
         sccs        :1;   // SCC supported
   uint8 adr16       :1,   // 16-bit wide SCSI addresses (SPI-5)
                     :2,   // reserved
                     :1,   // obsolete
         multip      :1,   // multiple SCSI ports
         vs          :1,   // vendor specific
         enclserv    :1,   // enclosure services
                     :1;   // obsolete
   uint8 vs2         :1,   // vendor specific
         cmdque      :1,   // tagged commands
                     :1,   // reserved
                     :1,   // obsolete
         sync        :1,   // synchronous transfers (SPI-5)
         wbus16      :1,   // 16-bit wide SCSI data transfers (SPI-5)
         wbus32      :1,   // SPC-4 reserved (SCSI2 wbus32)
                     :1;   // obsolete
   uint8 manufacturer[8];  // manufacturer's name in ascii
   uint8 product[16];   // product name in ascii
   uint8 revision[4];   // product version number in ascii
} SCSIInquiry36Response;   // standard INQUIRY response format

#define SCSI_STANDARD_INQUIRY_MIN_LENGTH 36

/*
 * Format of standard SCSI3 INQUIRY response block.
 * See spc4r37, Section 6.6.2 table 176
 *
 * You should use this one and not one above if you need
 * vendor1/reserved fields.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   SCSIInquiry36Response inq; // Standard SCSI3 36 byte response data
   uint8 vs[20];           // Vendor specific Inquiry data
   uint8 ius         :1,   // Information Units Supported (see SPI-5)
         qas         :1,   // Quick Arb and Selection (see SPI-5)
         clocking    :2,   // Clocking support (see SPI-5)
                     :4;
   uint8 resv1;
   /*
    * Possible vscsi version descriptors for long format response data
    * See spc4r37 Section 6.6.2 Table 182
    */
#define SCSI3_VERSION_DESC_SAM2        0x0040   // SAM-2 no version claimed
#define SCSI3_VERSION_DESC_SAM3        0x0060   // SAM-3 no version claimed
#define SCSI3_VERSION_DESC_SAM4        0x0080   // SAM-4 no version claimed
#define SCSI3_VERSION_DESC_SAM5        0x00A0   // SAM-5 no version claimed
#define SCSI3_VERSION_DESC_SBC2        0x0320   // SBC-2 no version claimed
#define SCSI3_VERSION_DESC_SBC3        0x04C0   // SBC-3 no version claimed
#define SCSI3_VERSION_DESC_SBC4        0x0600   // SBC-4 no version claimed
#define SCSI3_VERSION_DESC_SPC2        0x0260   // SPC-2 no version claimed
#define SCSI3_VERSION_DESC_SPC3        0x0300   // SPC-3 no version claimed
#define SCSI3_VERSION_DESC_SPC4        0x0460   // SPC-4 no version claimed
#define SCSI3_VERSION_DESC_SPC5        0x05C0   // SPC-5 no version claimed
   uint16 version_desc[8]; // Start of VERSION DESCRIPTORS (8);
   uint8 reserved[22];     // Reserved and vendor specific

}
#include "vmware_pack_end.h"
SCSI3InquiryResponse;   // Standard SCSI3 INQUIRY response format


#define SCSI_INQ_PAGE_0x00 0x00
#define SCSI_INQ_PAGE_0x80 0x80
#define SCSI_INQ_PAGE_0x83 0x83
#define SCSI_INQ_PAGE_0x89 0x89
#define SCSI_INQ_PAGE_0xB0 0xB0
#define SCSI_INQ_PAGE_0xB1 0xb1
#define SCSI_INQ_PAGE_0xB2 0xb2

/*
 * The following structures define the Page format supported by the
 * vscsi layer in vmkernel. The SPC-3 r23 spec defines a very generic
 * layout of these pages, however the structures here are customized
 * for vmkernel.
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPage00ResponseHeader {
   uint8 devClass :5,
         pQual    :3;
   uint8 pageCode;
   uint8 pageLengthMSB;        // The SPC-4 spec has a 2 byte page len field
   uint8 pageLength;
}
#include "vmware_pack_end.h"
SCSIInqPage00ResponseHeader;

typedef
#include "vmware_pack_begin.h"
struct SCSIInqPage80ResponseHeader {
   uint8 devClass :5,
         pQual    :3;
   uint8 pageCode;
   uint8 pageLengthMSB;        // The SPC-4 spec has a 2 byte page len field
   uint8 pageLength;
}
#include "vmware_pack_end.h"
SCSIInqPage80ResponseHeader;

// Inquiry page 0x83: Identifier Type
#define SCSI_IDENTIFIERTYPE_VENDOR_SPEC   0x0
#define SCSI_IDENTIFIERTYPE_T10           0x1
#define SCSI_IDENTIFIERTYPE_EUI           0x2
#define SCSI_IDENTIFIERTYPE_NAA           0x3
#define SCSI_IDENTIFIERTYPE_RTPI          0x4
#define SCSI_IDENTIFIERTYPE_TPG           0x5
#define SCSI_IDENTIFIERTYPE_LUG           0x6
#define SCSI_IDENTIFIERTYPE_MD5           0x7
#define SCSI_IDENTIFIERTYPE_SNS           0x8
#define SCSI_IDENTIFIERTYPE_PROTOCOL_SPEC 0x9
#define SCSI_IDENTIFIERTYPE_RESERVED      0xA
#define SCSI_IDENTIFIERTYPE_MAX           SCSI_IDENTIFIERTYPE_RESERVED

// Inquiry page 0x83: Transport Layer
#define SCSI_PROTOCOLID_FCP2        0x0
#define SCSI_PROTOCOLID_SPI5        0x1
#define SCSI_PROTOCOLID_SSAS3P      0x2
#define SCSI_PROTOCOLID_SBP3        0x3
#define SCSI_PROTOCOLID_SRP         0x4
#define SCSI_PROTOCOLID_ISCSI       0x5
#define SCSI_PROTOCOLID_SAS         0x6
#define SCSI_PROTOCOLID_ADT         0x7
#define SCSI_PROTOCOLID_ATA         0x8
#define SCSI_PROTOCOLID_RESERVED    0xE
#define SCSI_PROTOCOLID_NO_PROTOCOL 0xF

// Inquiry page 0x83: UUID Encoding
#define SCSI_CODESET_BINARY   0x1
#define SCSI_CODESET_ASCII    0x2
#define SCSI_CODESET_UTF8     0x3
#define SCSI_CODESET_RESERVED 0xF

// Inquiry page 0x83: UUID Entity
#define SCSI_ASSOCIATION_LUN           0x0
#define SCSI_ASSOCIATION_TARGET_PORT   0x1
#define SCSI_ASSOCIATION_TARGET_DEVICE 0x2
#define SCSI_ASSOCIATION_RESERVED      0x3

/*
 * Device Identification VPD page header
 * See spc4r37 section 7.8.6.1 table 589
 * Note: MANDATORY VPD Page for SPC4
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPage83ResponseHeader {
   uint8  devClass   :5,
          pQual      :3;
   uint8  pageCode;
   uint16 pageLength;
}
#include "vmware_pack_end.h"
SCSIInqPage83ResponseHeader;

/*
 * Device Identification VPD page Designation descriptor
 * See spc4r37 section 7.8.6.1 table 590
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPage83ResponseDescriptor {
   /* Identification Descriptor follows */
   uint8  codeSet     :4,  // Code Set enumeration
          protocolId  :4;  // Protocol Identifier
   uint8  idType      :4,  // DESIGNATOR TYPE field
          association :2,  // Designator Association
          reserved1   :1,
          piv         :1;  // protocol identifier valid
   uint8  reserved2;
   uint8  idLength;
}
#include "vmware_pack_end.h"
SCSIInqPage83ResponseDescriptor;

/*
 * Page83 structs differ for SCSI2 (actually SCSI3 SPC2).
 * See spc2r18 section 8.4.4 table 177
 */
typedef
#include "vmware_pack_begin.h"
struct SCSI2InqPage83ResponseHeader {
   uint8  devClass      :5,
          pQual         :3;
   uint8  pageCode;
   uint8  reserved;
   uint8  pageLength;
}
#include "vmware_pack_end.h"
SCSI2InqPage83ResponseHeader;

/*
 * Page83 structs differ for SCSI2 (actually SCSI3 SPC2).
 * See spc2r18 section 8.4.4 table 178
 */
typedef
#include "vmware_pack_begin.h"
struct SCSI2InqPage83ResponseDescriptor {
   /* Identification Descriptor follows */
   uint8  codeSet     :4,
          reserved    :4;
   uint8  idType      :4,  // Only Types 0x1 - 0x4 are valid for spc2r18
          association :2,
          reserved1   :2;
   uint8  reserved2;
   uint8  idLength;
}
#include "vmware_pack_end.h"
SCSI2InqPage83ResponseDescriptor;

/*
 * SCSI VPD Page 86 inquiry response per spc4r36d Table 616.
 * Extended INQUIRY Data VPD page
 *
 * XXX The two fields depLU and supLU are not yet included in the
 *     standard. They are still in proposal stage. We might have to
 *     change/update them accordingly as the proposal goes forward.
 *
 *     PR 932384
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPage86Response {
   uint8  devClass      :5,
          pQual         :3;
   uint8  pageCode;
   uint16 pageLength;
   uint8  refChk        :1,
          appChk        :1,
          grdChk        :1,
          spt           :3,
          actUcode      :2;

   uint8  simSup        :1,
          ordSup        :1,
          headSup       :1,
          priorSup      :1,
          groupSup      :1,
          uaskSup       :1,
          res1          :2;

   uint8  vSup          :1,
          nvSup         :1,
          crdSup        :1,
          wuSup         :1,
          res2          :4;

   uint8  luiClr        :1,
          res3          :3,
          piiSup        :1,
          res4          :3;

   uint8  cbcs          :1,
          res5          :3,
          rSup          :1,
          res6          :3;

   uint8  multiUcode    :4,
          res7          :4;

   uint16 extSelfTestMins;

   uint8  depLU         :1,
          supLU         :1,   /* PE */
          res8          :3,
          vsaSup        :1,
          hraSup        :1,
          poaSup        :1;

   uint8  maxSenseDataLen;    // Maximun supported sense data length

   /*
    * Reserved bytes - 14 - 63
    */
   uint8  res9[50];
}
#include "vmware_pack_end.h"
SCSIInqPage86Response;

#define SCSI_INQ_PAGE_89_LEN                   572

/*
 * Format of INQUIRY EVPD Page 89 response
 * While listed in spc4r22 section 7.7.1 table 475 it is documented in
 * SAT-r09, Section 12.4.2.1 Table 100
 *
 * For interpretation of ATA IDENTIFY DEVICE data (idData)
 * please refer to SAT-3 T10/2126-D, Revision 4, Section 12.4.2.3 and
 * ATA/ATAPI Command Set - 3 (T13/2161-D) Revision 5, Section 7.12.7.1 Table 45 
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPage89Response {
   uint8  devClass  :5,
          pQual     :3;
   uint8  pageCode;
   uint16 pageLength;
   uint8  reserved1[4];
   uint8  vendorID[8];
   uint8  productID[16];
   uint8  revLevel[4];
   uint8  deviceSignature[20];
   uint8  commandCode;
/* ATA Command Code for IDENTIFY DEVICE (commandCode) */
#define SCSI_VPD89_ATA_IDENTIFY_DEVICE_CMD_CODE     0xEC
   uint8  reserved2[3];
   /* Offsets into idData */
#define SCSI_VPD89_ATA_DSM_TRIM_LBPRZ_WORD_OFFSET              69 
#define SCSI_VPD89_ATA_MAJOR_VERSION_WORD_OFFSET               80 
#define SCSI_VPD89_ATA_MAJOR_VERSION_OFFSET                   160
#define SCSI_VPD89_ATA_MAX_DSM_BLOCK_DESCRIPTORS_WORD_OFFSET  105
#define SCSI_VPD89_ATA_DSM_FEATURES_WORD_OFFSET               169
#define SCSI_VPD89_ATA_MEDIUM_ROT_RATE_OFFSET                 434
#define SCSI_VPD89_ATA_SCT_FEATURE_CONTROL_WORD_OFFSET        206
   uint8  idData[512];
}
#include "vmware_pack_end.h"
SCSIInqPage89Response;

#define SCSI_ATA_DSM_DESCRIPTORS_PER_512_BYTE_SECTOR           64
#define SCSI_ATA_MAXIMUM_LBAS_PER_DSM_DESCRIPTOR          0xffffu

/* For ATA Major Number information refer to
 * ATA/ATAPI Command Set - 3 (T13/2161-D) Revision 5, Section 7.12.7.38,
 * Table 45.
 */
#define SCSI_VPD89_ATA_IS_VALID_MAJOR_NUMBER(num)  ((num) != 0xFFFF &&\
                                                    (num) != 0x0)
#define SCSI_VPD89_ATA_MAJOR_VERSION_MASK(major)   (1 << (major))
#define SCSI_VPD89_ATA_MAJOR_NUMBER_SUPPORTS_ACS3  10
#define SCSI_VPD89_ATA_MAJOR_NUMBER_SUPPORTS_ATAPI7 7
#define SCSI_VPD89_ATA_MAJOR_NUMBER_SUPPORTS_ATAPI5 5

/* 
 * For medium rotation rate, please refer to
 * ATA/ATAPI Command Set 2 (T13/2015-D) Revision 2, Section 7.18.7.81
 */
#define SCSI_VPD89_ATA_NON_ROTATING_MEDIUM          0x1


#define SCSI_INQ_PAGE_B0_LEN                   64
#define SCSI_INQ_PAGE_B1_LEN                   64
#define SCSI_INQ_PAGE_B2_LEN                   64

/*
 * Format of INQUIRY EVPD Page B2 response
 * Logical Block Provisioning VPD page
 * SBC3-r36, Section 6.6.4 table 210 Page 290
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIInqPageB2ResponseHeader {
   uint8  devClass   :5,
          pQual      :3;
   uint8  pageCode;
#define SCSI_B2_RESP_LEN_DP0_INQ_PAGE_0xB2 0x04
   uint16 pageLength;
   uint8  thresholdExp;       // Threshold exponent
   uint8  dp         :1,      // PROVISIONING GROUP DESCRIPTOR present
          anc_sup    :1,      // Anchored LBAs supported
          lbprz      :1,      // Logical block provisioning read zeros
                     :2,
          lbpws10    :1,      // WRITE_SAME10 supported
          lbpws      :1,      // WRITE_SAME16 supported
          lbpu       :1;      // UNMAP command supported
#define SCSI_B2_LU_IS_FP 0x00    // Fully provisioned (or type unreported)
#define SCSI_B2_LU_IS_RP 0x01    // Resource provisioned
#define SCSI_B2_LU_IS_TP 0x02    // Thin provisioned
   uint8  provType   :3,         // Provisioning type, sbc3r36 6.6.4 table 211
                     :5;
   uint8  Reserved;
}
#include "vmware_pack_end.h"
SCSIInqPageB2ResponseHeader;

/*
 * Format of INQUIRY EVPD Page B1 response
 * Block Device Characteristics Page
 * SBC3-r18, Section 6.5.3 table 138 Page 178
 * SBC3-r36, Section 6.6.2 table 202 Page 284
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPageB1ResponseHeader {
   uint8  devClass	:5,
          pQual         :3;
   uint8  pageCode;
   uint8  lengthMSB;        // The SPC-4 spec has a 2 byte len field
   uint8  pageLength;
// Inquiry page 0xB1: Medium Rotation Rate
#define SCSI_ROTATION_RATE_NOT_REPORTED        0x00
#define SCSI_ROTATION_RATE_NON_ROTATING_MEDIUM 0x01
#define SCSI_ROTATION_RATE_7200_RPM            0x1c20
#define SCSI_ROTATION_RATE_10000_RPM           0x2710
#define SCSI_ROTATION_RATE_15000_RPM           0x3a98
   uint16 mediumRotationRate; // See sbc3r36 Sec 6.6.2 Table 203
#define SCSI_B1_PROD_TYPE_NOT_INDICATED   0x00
#define SCSI_B1_PROD_TYPE_CFast           0x01  // (tm)
#define SCSI_B1_PROD_TYPE_CompactFlash    0x02  // (r)
#define SCSI_B1_PROD_TYPE_MemoryStick     0x03  // (tm)
#define SCSI_B1_PROD_TYPE_MultiMediaCard  0x04
#define SCSI_B1_PROD_TYPE_SD_CARD         0x05
#define SCSI_B1_PROD_TYPE_XQD             0x06  // (tm)
#define SCSI_B1_PROD_TYPE_UFS             0x07  // Universal Flash Storage
   uint8  productType;     // See sbc3r36 Sec 6.6.2 Table 204
#define SCSI_FORM_FACTOR_NOT_REPORTED  0x0
#define SCSI_FORM_FACTOR_5_25_INCH     0x1
#define SCSI_FORM_FACTOR_3_5_INCH      0x2
#define SCSI_FORM_FACTOR_2_5_INCH      0x3
#define SCSI_FORM_FACTOR_1_8_INCH      0x4
#define SCSI_FORM_FACTOR_LT_1_8_INCH   0x5
   uint8  formFactor:4,    // See sbc3r36 Sec 6.6.2 Table 207
#define SCSI_B1_WACEREQ_NOT_SPECIFIED        0x00
#define SCSI_B1_WACEREQ_COMP_GOOD            0x01
#define SCSI_B1_WACEREQ_CC_MEDIUM_ERR        0x02
#define SCSI_B1_WACEREQ_CC_WR_AFTER_SAN_REQ  0x03
          wacereq   :2,    // write after cryptographic erase required
                           // See sbc3r36 Sec 6.6.2 Table 206
#define SCSI_B1_WABEREQ_NOT_SPECIFIED        0x00
#define SCSI_B1_WABEREQ_COMP_GOOD            0x01
#define SCSI_B1_WABEREQ_CC_MEDIUM_ERR        0x02
#define SCSI_B1_WABEREQ_CC_WR_AFTER_SAN_REQ  0x03
          wabereq   :2;    // write after block erase required
                           // See sbc3r36 Sec 6.6.2 Table 205
   uint8  vbuls     :1,    // verify byte check unmapped LBA supported
          fuab      :1,    // force unit access/SYNCHRONIZE CACHE behavior per spec
                    :6;
   uint8  reserved[55];
}
#include "vmware_pack_end.h"
SCSIInqPageB1ResponseHeader;

/*
 * Block Limits VPD page 0xB0
 * See SBC3R36 section 6.6.3 page 287, table 208
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPageB0ResponseHeader {
   uint8  devClass   :5,
          pQual      :3;
   uint8  pageCode;
#define SCSI_B0_RESP_LEN_TP_SUPPORTED     0x3C
#define SCSI_B0_RESP_LEN_TP_NOT_SUPPORTED 0x10
   uint8  lengthMSB;        // The SPC-4 spec has a 2 byte len field
   uint8  pageLength;
}
#include "vmware_pack_end.h"
SCSIInqPageB0ResponseHeader;

/*
 * Block Limits VPD page 0xB0
 * See SBC3R36 section 6.6.3 page 287, table 208
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIInqPageB0ResponseDescriptor {
   uint8  wsnz:1,                   /* Allow zero in NOB field in WriteSame */
          reserved:7;
   uint8  maxAtsLen;                /* Max compare and write Length */
   uint16 optimalTransLenGran;      /* Optimal transfer length granularity */
   uint32 maxTransLen;              /* Maximum transfer length */
   uint32 optimalTransLen;          /* Optimal transfer length for a single cmd */
   uint32 maxPrefetchTransLen;      /* Limit for PRE-FETCH command */
   uint32 maxUnmapLbaCount;         /* Maximum number of LBAs per UNMAP cmd */
   uint32 maxUnmapDescriptorCount;  /* Max number of UNMAP block desc per UNMAP */
   uint32 optimalUnmapGranularity;  /* Optimal granularity for UNMAP */
   /* 
    * The unmap alignment field is a 31 bit value, while the endian conversion
    * needs to happen on all 4 bytes. The union helps achieve this by giving a
    * 4-byte field to work on for the conversion.
    */ 
   union {
      struct {
         uint32 alignment:31,       /* first LBA which optimal granularity applies */
                ugaValid:1;         /* Unmap granularity validity */
      } ugaInfo;
      uint32 info;
   } unmapAlignmentInfo;
   uint64 maxWriteSameLength;
   uint8  reserved2[20];
}
#include "vmware_pack_end.h"
SCSIInqPageB0ResponseDescriptor;

typedef
#include "vmware_pack_begin.h"
struct SCSIInquiryVPDResponseHeader {
   uint8 devclass    :5,   // SCSI device class
         pqual       :3;   // peripheral qualifier
   uint8 pageCode;         // 0
   uint8 lengthMSB;        // The SPC-4 spec has a 2 byte len field
   uint8 payloadLen;       // Number of additional bytes
}
#include "vmware_pack_end.h"
SCSIInquiryVPDResponseHeader;

typedef
#include "vmware_pack_begin.h"
struct SCSIReportLunsCmd {
   uint8 opcode;           // (0xA0)
   uint8 reserved1;
#define SCSI_RL_SELECT_REPORT_DEFAULT   0x00 // default report
#define SCSI_RL_SELECT_REPORT_WN        0x01 // well known LUNs only
#define SCSI_RL_SELECT_REPORT_ALL       0x02 // all LUNs
/*
 * Refer to SPC4r37 Section 6.33 Table 288 for 0x10-0x12.
 * ALU == Administrative Logical Unit (aka PE)
 * SLU == Subsidiary Logical Unit (aka second level lun)
 */
#define SCSI_RL_SELECT_REPORT_ALU_ONLY  0x10 // ALUs only
#define SCSI_RL_SELECT_REPORT_ALU_L1    0x11 // ALUs and 1st level LUNs
#define SCSI_RL_SELECT_REPORT_ALU_SLU   0x12 // ALU and SLUs under it
   uint8 selectReport;
   uint8 reserved2[3];
   uint32 allocLen;
   uint16 reserved3;
}
#include "vmware_pack_end.h"
SCSIReportLunsCmd;

/* See SAM3R14 section 4.9.4 page 34 */
typedef
#include "vmware_pack_begin.h"
struct SCSIReportLunsResponse {
   uint32 len;
   uint32 reserved;
   struct {
      uint8  busIdentifier:6,
             addressMethod:2;
      uint8  singleLevelLun;
      uint16 secondLevelLun;
      uint16 thirdLevelLun;
      uint16 fourthLevelLun;
   } lun[1];
}
#include "vmware_pack_end.h"
SCSIReportLunsResponse;

/*
 * Note: sam5r20 is the latest spec, but it has not been approved yet.
 *       The references to sam5r06 should be updated with the approved documents
 *       section and table numbers.
 *
 * SAM5r06 section 4.7.5 Tables 11 and 12 uses 2 bytes per level
 * and two bits for the address method. This leaves 14 bits for the
 * actual LUN.
 */
#define SCSI_MAX_SINGLE_LEVEL_LUN (1 << 14)

/*
 * SAM5r06 sections 4.7.10 Tables 21,22,27 and 4.7.12 Table 29 define
 * a variable length extended flat space addressing LUN format.
 * This format leaves upto 40 bits for actual LUN address
 * if used as the second level LUN address.
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIExtendedFlatLun {
   uint8 extendedAddressMethod :4, // should be 0x2
         length                :2, // should be 0x1 (24 bits) or 0x2 (40 bits)
         addressMethod         :2; // should be 0x3
   uint8 flatLun[5];
}
#include "vmware_pack_end.h"
SCSIExtendedFlatLun;

#define SCSI_REPORT_LUNS_RESPONSE_LEN(n) (sizeof(SCSIReportLunsResponse) + ((n)-1) * sizeof(((SCSIReportLunsResponse*)0)->lun[0]))

// SPC-3, Section 6.6 Table 93
typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;        // operation code
   uint8  sp       :1,
          ppc      :1,
          reserved1:6;
   uint8  page     :6,
#define SCSI_LS_PAGE_SUPPORTED                   0x00
#define SCSI_LS_PAGE_BUF_OVER_UNDER_RUN          0x01
#define SCSI_LS_PAGE_WRITE_ERROR_COUNTER         0x02
#define SCSI_LS_PAGE_READ_ERROR_COUNTER          0x03
#define SCSI_LS_PAGE_READ_REVERSE_ERROR_COUNTER  0x04
#define SCSI_LS_PAGE_VERIFY_ERROR_COUNTER        0x05
#define SCSI_LS_PAGE_NON_MEDIUM_ERROR            0x06
#define SCSI_LS_PAGE_LASTN_ERROR_EVENTS          0x07
#define SCSI_LS_PAGE_FORMAT_STATUS               0x08
#define SCSI_LS_PAGE_LASTN_DEFERRED_ERRORS       0x0b
#define SCSI_LS_PAGE_TEMPERATURE                 0x0d
#define SCSI_LS_PAGE_SEQUENTIAL_DEVICE           0x0c
#define SCSI_LS_PAGE_START_STOP_CYCLE_COUNTER    0x0e
#define SCSI_LS_PAGE_APPLICATION_CLIENT          0x0f
#define SCSI_LS_PAGE_SELFTEST_RESULTS            0x10
#define SCSI_LS_PAGE_DTD_STATUS                  0x11
#define SCSI_LS_PAGE_TAPE_ALERT_RESPONSE         0x12
#define SCSI_LS_PAGE_REQUESTED_RECOVERY          0x13
#define SCSI_LS_PAGE_DEVICE_STATISTICS           0x14
#define SCSI_LS_PAGE_NONVOLATILE_CACHE           0x17
#define SCSI_LS_PAGE_PROTOCOL_SPECIFIC_PORT      0x18
#define SCSI_LS_PAGE_TAPE_ALERT                  0x2e
#define SCSI_LS_PAGE_INFORMATIONAL_EXCEPTIONS    0x2f
          pc       :2;
#define SCSI_LS_PC_THRESHOLD          0x00
#define SCSI_LS_PC_CUMULATIVE         0x01
#define SCSI_LS_PC_DEFAULT_THRESHOLD  0x02
#define SCSI_LS_PC_DEFAULT_CUMULATIVE 0x04
   uint16 reserved2;
   uint16 paramPointer;
   uint16 length;        // allocation length
   uint8  control;
}
#include "vmware_pack_end.h"
SCSILogSenseCmd;

// SPC-3, Section 7.2.1 Table 197
typedef struct {
   uint8    page     :6,
            reserved1:2;
   uint8    reserved2;
   uint16   length;
} SCSILogHeader;

// SPC-3, Section 7.2.5 Table 211
typedef
#include "vmware_pack_begin.h"
struct {
   uint16 paramCode;
   uint8  lp    :1,
          lbin  :1,
          tmc   :2,
          etc   :1,
          tsd   :1,
          ds    :1,
          du    :1;
   uint8  length;
   uint8  asc;
   uint8  ascq;
   uint8  mostRecentTemperature;
}
#include "vmware_pack_end.h"
SCSIInformationalExceptionsParam;

// SPC-3, Section 7.2.11 Table 219
typedef
#include "vmware_pack_begin.h"
struct {
   // Date of manufacture
   uint16 dateParamCode;
   uint8  reserved1;
   uint8  dateParamLength;
   uint8  yearofMF[4];
   uint8  weekofMF[2];
   
   // Accounting info
   uint16 accountParamCode;
   uint8  reserved2;
   uint8  accountParamLength;
   uint8  yearofAccounting[4];
   uint8  weekofAccounting[2];

   // Cycle count params
   uint16 cycleCountParamCode;
   uint8  reserved3;
   uint8  cycleCountParamLength;
   uint32 cycleCount;

   // Accumulated start-stop cycles
   uint16 startStopCycleCountParamCode;
   uint8  reserved4;
   uint8  startStopCycleCountParamLength;
   uint32 startStopCycleCount;
}
#include "vmware_pack_end.h"
SCSIStartStopLogPage;

/*
 * FORMAT UNIT command
 * See sbc3r36 Table 34
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;      // FORMAT UNIT (0x4)
   uint8  dlf     :3,  // defect list format
          cmplst  :1,  // complete list
          fmtdata :1,  // format data
          longlist:1,  // long list
          fmtpinfo:2;
   uint8  vs;
   uint16 interleave;  // SCSI2 only - Obsolete
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIFormatCmd;

/*
 * FORMAT UNIT Short Parameter List Header
 * See sbc3r36 Table 37
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 pfu      :3,   // protection field usage
         reserved :5;
   uint8 vs       :1,
         immed    :1,   // immediate
         obslt    :1,
         ip       :1,   // initialization pattern
         stpf     :1,   // stop format
         dcrt     :1,   // disable certification
         dpry     :1,   // disable primary
         fov      :1;   // Format options valid
   uint16 defectlist;   // defect list length
}
#include "vmware_pack_end.h"
SCSIFormatShortParamListHdr;

/*
 * FORMAT UNIT Long Parameter List Header
 * See sbc3r36 Table 38
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 pfu      :3,   // protection field usage
         reserved :5;
   uint8 vs       :1,
         immed    :1,   // immediate
         obslt    :1,
         ip       :1,   // initialization pattern
         stpf     :1,   // stop format
         dcrt     :1,   // disable certification
         dpry     :1,   // disable primary
         fov      :1;   // Format options valid
   uint8 reserved1;
   uint8 piexp    :4,   // Protection Interval Exponent
         p_i_info :4;   // See sbc3r36 section 5.3.2.2
   uint32 defectlist;   // defect list length
}
#include "vmware_pack_end.h"
SCSIFormatLongParamListHdr;

/*
 * Format Defect List header
 * SCSI2 Only - Obsolete
 * See ANSI X3.131-199x Table 111
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 reserved;
   uint8 vs    :1,
         immed :1,   // immediate
         dsp   :1,   // disable saving parameters
         ip    :1,   // initialization pattern
         stpf  :1,   // stop format
         dcrt  :1,   // disable certification
         dpry  :1,   // disable primary
         fov   :1;   // Format options valid
   uint16 length;    // Defect list length
}
#include "vmware_pack_end.h"
SCSIDefectListHdr;

/*
 * Format of 6- and 10-byte versions of the MODE SELECT
 * and MODE SENSE request and response blocks.
 * These are defined here because multiple SCSI devices
 * may need them.
 *
 * Conforms to spc4r37 section 6.13.1 table 199
 * NOTE 29 - Implementations should migrate from the MODE SENSE(6)
 *           command to the MODE SENSE(10) command.
 */
typedef struct {
   uint8 opcode;        // operation code (0x15)
   uint8          :3,
         dbd      :1,   // disable block descriptors
                  :4;
   uint8 page     :6,   // page code
#define SCSI_MS_PAGE_VENDOR   0x00     // vendor-specific (ALL)
#define SCSI_MS_PAGE_RWERROR  0x01     // read/write error (DISK/TAPE/CDROM/OPTICAL)
#define SCSI_MS_PAGE_CONNECT  0x02     // disconnect/connect (ALL)
#define SCSI_MS_PAGE_FORMAT   0x03     // format (DISK)
#define SCSI_MS_PAGE_PARALLEL 0x03     // parallel interface (PRINTER)
#define SCSI_MS_PAGE_UNITS    0x03     // measurement units (SCANNER)
#define SCSI_MS_PAGE_GEOMETRY 0x04     // rigid disk geometry (DISK)
#define SCSI_MS_PAGE_SERIAL   0x04     // serial interface (PRINTER)
#define SCSI_MS_PAGE_FLEXIBLE 0x05     // flexible disk geometry (DISK)
#define SCSI_MS_PAGE_PRINTER  0x05     // printer operations (PRINTER)
#define SCSI_MS_PAGE_OPTICAL  0x06     // optical memory (OPTICAL)
#define SCSI_MS_PAGE_VERIFY   0x07     // verification error (DISK/CDROM/OPTICAL)
#define SCSI_MS_PAGE_CACHE    0x08     // cache (DISK/CDROM/OPTICAL)
#define SCSI_MS_PAGE_PERIPH   0x09     // peripheral device (ALL)
#define SCSI_MS_PAGE_CONTROL  0x0a     // control mode (ALL)
#define SCSI_MS_PAGE_MEDIUM   0x0b     // medium type (DISK/CDROM/OPTICAL)
#define SCSI_MS_PAGE_NOTCH    0x0c     // notch partitions (DISK)
#define SCSI_MS_PAGE_CDROM    0x0d     // CD-ROM (CDROM)
#define SCSI_MS_PAGE_CDAUDIO  0x0e     // CD-ROM audio (CDROM)
#define SCSI_MS_PAGE_COMPRESS 0x0f     // data compression (TAPE)
#define SCSI_MS_PAGE_CONFIG   0x10     // device configuration (TAPE)
#define SCSI_MS_PAGE_POWER    0x1a     // power condition (CDROM)
#define SCSI_MS_PAGE_EXCEPT   0x1c     // informal exception (ALL:SCSI-3)
#define SCSI_MS_PAGE_THINP    0x1c     // thin provisioning (DISK)
#define SCSI_MS_PAGE_TIMEOUT  0x1d     // time-out and protect (CDROM)
#define SCSI_MS_PAGE_CDCAPS   0x2a     // CD-ROM capabilities and mechanical status (CDROM)
// more defined...
#define SCSI_MS_PAGE_ALL      0x3f     // all available pages (ALL)
         pcf      :2;   // page control field
#define SCSI_MS_PCF_CURRENT    0x00    // current values
#define SCSI_MS_PCF_VOLATILE   0x01    // changeable values
#define SCSI_MS_PCF_DEFAULT    0x02    // default values
#define SCSI_MS_PCF_SAVED      0x03    // saved values
   uint8    subpage;
#define SCSI_MS_SUBPAGE_THINP        0x02 // thin provisioning subpage (DISK)
#define SCSI_MS_SUBPAGE_CONTROL_EXT  0x01 // control extension subpage
#define SCSI_MS_SUBPAGE_ALL          0xff // return all subpages
   uint8    length;        // data length
   uint8    control;       // control byte
} SCSIModeSenseCmd;

/*
 * MODE SENSE(10) command
 * Conforms to spc4r37 section 6.14 table 202
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;        // operation code (0x5a)
   uint8            :3,
            dbd     :1,    // disable block descriptors
            llbaa   :1,    // Long LBA Accepted
                    :3;
   uint8    page    :6,    // page code
            pcf     :2;    // page control field
   uint8    subpage;
   uint8    reserved[3];
   uint16   length;	   // data length
   uint8    control;       // control byte
}
#include "vmware_pack_end.h"
SCSIModeSense10Cmd;

/*
 * MODE SELECT(6) command
 * Conforms to spc4r37 section 6.11 table 197
 * NOTE 27 - Implementations should migrate from the MODE SELECT(6)
 *           command to the MODE SELECT(10) command.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;     // operation code (0x15)
   uint8    sp    :1,   // save pages
                  :3,
            pf    :1,   // page format
                  :3;
   uint8    reserved[2];
   uint8    length;     // data length
   uint8    control;    // control byte
}
#include "vmware_pack_end.h"
SCSIModeSelectCmd;

/*
 * MODE SELECT(10) command
 * Conforms to spc4r37 section 6.12 table 198
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;     // operation code (0x55)
   uint8    sp   :1,    // save pages
                 :3,
            pf   :1,    // page format
                 :3;
   uint8    reserved[5];
   uint16   length;     // data length
   uint8    control;    // control byte
}
#include "vmware_pack_end.h"
SCSIModeSelect10Cmd;

/*
 * Mode parameter header(6)
 * See spc4r37 section 7.5.5 table 454
 */
typedef struct {
   uint8    len;           // data length
   uint8    mediaType;
   uint8    devSpecific;   // device specific
   uint8    bdLen;         // block descriptor length
} SCSIModeHeader6;

/*
 * Mode parameter header(10)
 * See spc4r37 section 7.5.5 table 455
 */
typedef struct {
   uint16   len;           // data length
   uint8    mediaType;
   uint8    devSpecific;   // device specific
   uint8    longlba:1,     // Long LBA
                   :7;
   uint8    reserved;
   uint16   bdLen;         // block descriptor length
} SCSIModeHeader10;

/*
 * DEVICE-SPECIFIC PARAMETER field for direct access block devices
 * See sbc3r36 section 6.5.1 table 180
 */
typedef struct {
   uint8 reserved1:4,
         dpofua   :1,   // disable page out / force unit access
         reserved2:2,
         wp       :1;   // write protected
} SCSIBlockModeSenseDeviceParameter;

/*
 * SCSI2 Short LBA mode parameter block descriptor
 * See ANSI X3.131-199x section 8.3.3 table 93
 * Also conforms to spc4r37 section 7.5.6.1 table 456
 */
typedef struct {
   uint8 density;
   uint8 numBlocks[3];
   uint8 reserved;
   uint8 blockLength[3];
} SCSI2ShortLBAModeParamBlockDesc;

/*
 * Short LBA mode parameter block descriptor
 * See sbc3r36 section 6.5.2.2 table 181
 */
typedef struct {
   uint8 numBlocks[4];
   uint8 reserved;
   uint8 blockLength[3];
} SCSIShortLBAModeParamBlockDesc;

/*
 * Long LBA mode parameter block descriptor
 * See sbc3r36 section 6.5.2.3 table 182
 * Used when 'longlba' is set to 1.
 */
typedef struct {
   uint8 numBlocks[8];
   uint8 reserved[4];
   uint8 blockLength[4];
} SCSILongLBAModeParamBlockDesc;

/*
 * Structure for Mode Caching Page.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8   page:6,      // page code: 0x08
           reserved1:1,
           ps:1;
   uint8   len;         // page length (0x12)
   uint8   rcd:1,
           mf:1,
           wce:1,   // set if device has a write cache and it is enabled
           size:1,
           disc:1,
           cap:1,
           abpf:1,
           ic:1;
   uint8   writePriority:4,
           readPriority:4;
   uint16  disablePrefetchTransferLength;
   uint16  minPrefetch;
   uint16  maxPrefetch;
   uint16  maxPrefetchCeiling;
   uint8   reserved2:3,
           vs:2,
           dra:1,
           lbcss:1,
           fsw:1;
   uint8 numCacheSegments;
   uint16 cacheSegmentSize;
   uint8 reserved3;
   uint8 nonCacheSegmentSize[3];
}
#include "vmware_pack_end.h"
SCSIModeSenseCachePage;

/*
 * There are three mandatory mode parameter pages for all device
 * types (a fourth is added in SCSI-3).  The following structures
 * define these pages as sent+received with MODE SENSE and SELECT.
 */
typedef struct {           // connect/disconnect page
   uint8    page  :6,      // page code: 0x02
                  :1,
            ps    :1;
   uint8    len;           // page length (0x0e)
   uint8    bufFull;
   uint8    bufEmpty;
   uint16   maxBusInactiveTime;
   uint16   maxBusFreeTime;
   uint16   maxConnectTime;
   uint16   maxBurstLength;
   uint8    dtdc  :3,
            dimm  :1,      // disconnect immediate (SCSI-3)
                  :3,
            emdp  :1;      // enable MODIFY DATA POINTER (SCSI-3)
   uint8    reserved;
   uint16   firstBurstSize;
} SCSIConnectPage;

/*
 * This page is obsolete in SPC and beyond
 */
typedef struct {     // peripheral device page
   uint8    page  :6,      // page code: 0x09
                  :1,
            ps    :1;
   uint8    len;           // page length (n-1)
   uint16   ifID;          // physical interface identifier
   uint8    reserved[4];
   uint8    undefined[1];  // variable-length vendor-specific data
} SCSIPeriphPage;

typedef
#include "vmware_pack_begin.h"
// SBC-4, Section 6.4.6 Table 153
struct {
   uint8    page  :6,      // page code: 0x1c
            spf   :1,      // spf: 1
            ps    :1;
   uint8    subpage;
   uint16   pageLength;
   uint8    sitpua:1,
            reserved1:7;
   uint8    reserved2[11];
}
#include "vmware_pack_end.h"
SCSIThinProvModePage;

typedef
#include "vmware_pack_begin.h"
// SPC-2, Section 8.3.3.1 Table 96
struct {
   uint8    page        :6,      // page code: 0x0a
            reserved1   :1,
            ps          :1;
   uint8    len;                // page: length (0x06)
   uint8    rlec        :1,
            reserved2   :7;
   uint8    dque                   :1,
            qerr                   :1,
            reserved3              :2,
            queueAlgorithmModifier :4;      // queue algorithm
   uint8    eaenp     :1,
            uaaenp    :1,
            raenp     :1,
            reserved4 :4,
            eeca      :1;
   uint8    reserved5;
   uint16   readyAENHoldoffPeriod;
}
#include "vmware_pack_end.h"
SCSI2ControlPage;

#define SCSI_CONTROL_PAGE_LENGTH 0xA
#define SCSI2_CONTROL_PAGE_LENGTH 0x6

/*
 * Control mode page
 * See spc4r37 section 7.5.8 table 459
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    page  :6,      // page code: 0x0a
            spf   :1,
            ps    :1;
   uint8    len;           // page length (0x0a)
   uint8    rlec        :1,
            gltsd       :1,
            d_sense     :1,      // descriptor format sense data
            dpicz       :1,      // disable protection information check if
                                 // protect field is zero
            tmf_only    :1,
            tst         :3;      // task set type
   uint8    obsolete1   :1,
            qerr        :2,      // queue error management
#define SCSI_QERR_TASKS_PROCESSED    0x0
#define SCSI_QERR_TASKS_ABORTED      0x1
#define SCSI_QERR_RESERVED           0x2
#define SCSI_QERR_I_T_TASKS_ABORTED  0x3
            nuar        :1,      // no unit attention on release
            queueAlgorithmModifier :4;      // queue algorithm
   uint8    obsolete2   :3,
            swp         :1,
            uaIntlckCtrl:2,
            rac         :1,      // report a check on busyTimeout
            vs          :1;      // vendor specific
   uint8    autoloadMode:3,
            reserved1   :1,
            rwwp        :1,      // reject write without protection
            atmpe       :1,      // application tag mode page enabled
            tas         :1,
            ato         :1;
   uint8    obsolete[2];
   uint16   busyTimeoutPeriod;         // busy timeout in 100ms (SCSI-3)
   uint16   extendedSelftestCompletionTime;
}
#include "vmware_pack_end.h"
SCSIControlPage;

/*
 * Control Extension mode page
 * See spc4r37 section 7.5.9 table 465
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    page  :6,        // page code: 0x0a
            spf   :1,
            ps    :1;
   uint8    subpage;         // 0x01
   uint16   pageLength;      // page length (0x1c)
   uint8    ialuae      :1,  // implicit asymmetric logical unit access
            scsip       :1,  // SCSI precedence
            tcmos       :1,  // timestamp changeable by methods outside
                             // this standard
                        :5;
   uint8    icp         :4,  // initial command priority
                        :4;
   uint8    maxsenselen;     // maximum sense data length
   uint8    reserved[25];
}
#include "vmware_pack_end.h"
SCSIControlExtensionPage;

// SPC-3, Section 7.4.11 Table 256
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    page     :6,   // page code: 0x1c
            spf      :1,
            ps       :1;
   uint8    len;           // page length (0x0a)
   uint8    logerr   :1,
            reserved1:1,
            test     :1,
            dexcpt   :1,
            ewasc    :1,
            ebf      :1,
            reserved2:1,
            perf     :1;
   uint8    mrie     :4,
            reserved3:4;
   uint32   intervalTimer;
   uint32   reportCount;
} 
#include "vmware_pack_end.h"
SCSIInformationalExceptionsControlPage;

typedef struct {
   uint8    page  :6,      // page code: 0x09
                  :1,
            ps    :1;
   uint8    len;           // page length 0x06
   uint8    dcr   :1,      // error recover parameters
            dte   :1,      // diable transfer on seeing recovered error
            per   :1,      // post error: report recovered errors
                  :1,
            rc    :1,      // read continuous: don't delay data transfer to correct errors
            tb    :1,      // transfer block when unrecovered
                  :2;
   uint8    readRetries;   // read retry count
   uint8    reserved[4];
} SCSIRWErrorPage;

typedef struct {
   uint8    page     :6,   // page code: 0x0d
                     :1,
            ps       :1;
   uint8    len;           // page length 0x06
   uint8             :8;
   uint8    inactive :4,   // head inactivity timeout
                     :4;
   uint16   secsPerMinute; // number of MSF seconds per MSF minute
   uint16   framesPerSec;  // number of MSF frames per MSF second
} SCSICDROMPage;

typedef struct {
   uint8    page     :6,   // page code: 0x0e
                     :1,
            ps       :1;
   uint8    len;           // page length 0x0e
   uint8             :1,
            sotb     :1,
            immediate:1,
                     :5;
   uint8             :8;
   uint8             :8;
   uint8    lbaFactor:4,
                     :3,
            aprv     :1;
   uint16   lbaPerSec;     // number of LBAs per second
   uint8    port0    :4,   // output port 0 select
                     :4;
   uint8    port0Volume;
   uint8    port1    :4,   // output port 1 select
                     :4;
   uint8    port1Volume;
   uint8    port2    :4,   // output port 2 select
                     :4;
   uint8    port2Volume;
   uint8    port3    :4,   // output port 3 select
                     :4;
   uint8    port3Volume;
} SCSICDROMAudioPage;

typedef struct {
   uint8    page     :6,   // page code: 0x1a
                     :1,
            ps       :1;
   uint8    len;           // page length 0x0a
   uint8    reserved;
   uint8    standby  :1,   // standby timer enabled
            idle     :1,   // idle timer enabled
                     :6;
   uint32   idleTimer;     // inactivity time until idle (100 ms)
   uint32   standbyTimer;  // inactivity time until standby (100 ms)
} SCSICDROMPowerPage;

typedef struct {
   uint8    page     :6,   // page code: 0x1d
                     :1,
            ps       :1;
   uint8    len;           // page length 0x08
   uint8    reserved1[2];
   uint8    swpp     :1,   // software write protect
            disp     :1,   // make unit unavailable until power is reapplied
            tmoe     :1,   // time out parameters are in effect
                     :5;
   uint8    reserved2;
   uint16   minTimeOut1;   // "Group 1 Minimum Time-out (Seconds)"
   uint16   minTimeOut2;   // "Group 2 Minimum Time-out (Seconds)"
} SCSICDROMTimeoutPage;

typedef struct {
   uint8    page     :6,   // page code: 0x2a
                     :1,
            ps       :1;
   uint8    len;           // page length 0x1e
   uint8    cdrRd    :1,   // CD-R read per Orange Book Part II
            cdeRd    :1,   // CD-E read per Orange Book Part III
            method2  :1,   // CD-R media w/ Addressing Method 2
            dvdromRd :1,   // DVD-ROM media read
            dvdrRd   :1,   // DVD-R media read
            dvdramRd :1,   // DVD-RAM media read
                     :2;
   uint8    cdrWr    :1,   // CD-R write per Orange Book Part II
            cdeWr    :1,   // CD-E write per Orange Book Part III
            testWr   :1,   // drive supports test write function
                     :1,
            dvdrWr   :1,   // DVD-R media write
            dvdramWr :1,   // DVD-RAM media write
                     :2;
   uint8    audioPlay:1,   // drive is capable of audio play
            composite:1,   // drive is capable of delivering composite audio+video
            digPort1 :1,   // drive supports digital output (IEC958) on port 1
            digPort2 :1,   // drive supports digital output on port 2
            mode2Form1:1,  // drive reads Mode 2 Form 1 (XA) format
            mode2Form2:1,  // drive reads Mode 2 Form 2 format
            multiSession:1,// drive reads multi-session or Photo-CD discs
            buf      :1;   // drive supports buffer underrun free recording
   uint8    cdDA     :1,   // CD-DA commands (Red Book) supported
            daAccu   :1,   // CD-DA stream is accurate
            rwSupported:1, // R-W supported
            rwDeinter:1,   // R-W subchannel data de-interleaved and corrected
            c2Ptrs   :1,   // C2 Error Pointers supported
            isrc     :1,   // drive returns International Standard Recording Code Info
            upc      :1,   // drive returns Media Catalog Number
            barcode  :1;   // drive returns disc bar code
   uint8    lock     :1,   // PREVENT/ALLOW commands lock media into drive
            lockState:1,   // current state of drive
            jumpers  :1,   // state of prevent/allow jumpers
            eject    :1,   // drive can eject disc via START/STOP command
                     :1,
            loadType :3;   // loading mechanism type
   uint8    sv       :1,   // separate volume
            scm      :1,   // separate channel mute
            sdp      :1,   // supports disc present in MECHANISM STATUS command
            sss      :1,   // s/w slot selection w/ LOAD/UNLOCK command
            scc      :1,   // supports both sides of discs
            rwinlin  :1,   // can read raw R-W subchannel data from lead-in
                     :2;
   uint16   oMaxSpeed;     // (obsolete) maximum speed supported (in KB/s)
   uint16   numVolLevels;  // number of volume levels supported
   uint16   bufSize;       // buffer size supported by drive (KBytes)
   uint16   oCurSpeed;     // (obsolete) current speed selected (in KB/s)
   uint8    reserved1;
   uint8             :1,   // format of digital data output
            bck      :1,   // data is valid on the falling edge of BCK
            rck      :1,   // HIGH on LRCK indicates left channel
            lsbf     :1,   // LSB first
            length   :2,
                     :2;
   uint16   oMaxWrSpeed;   // (obsolete) maximum write speed supported (in KB/s)
   uint16   oCurWrSpeed;   // (obsolete) current write speed (in KB/s)
   uint16   copyRev;       // version of DVD Content Protection supported
   uint8    reserved2[3];
   uint8    rotation :2,   // current rotation control
                     :6;
   uint16   curWrSpeed;    // current write speed (in KB/s)
   uint16   numWrDescs;    // number of write speed performance descriptors
} SCSICDROMCapabilitiesPage;

typedef struct {
   uint8    page  :6,         // page code: 0x03
                  :1,
            ps    :1;
   uint8    len;              // page length 0x16
   uint16   tracksPerZone;
   uint16   repSectorsPerZone;
   uint16   repTracksPerZone;
   uint16   replTracksPerLUN;
   uint16   sectorsPerTrack;
   uint16   bytesPerSector;
   uint16   interleave;
   uint16   trackSkew;
   uint16   cylinderSkew;
   uint8          :3,
            surf  :1,
            rmb   :1,
            hsec  :1,
            ssec  :1;
   uint8    reserved[3];
} SCSIFormatPage;

typedef uint8 uint24[3];

typedef struct {
   uint8    page  :6,         // page code: 0x04
                  :1,
            ps    :1;
   uint8    len;              // page length 0x16
   uint24   cylinders;        // number of cylinders
   uint8    heads;            // number of heads
   uint24   writeCompCylinder; // starting cylinder for write compensation
   uint24   writeCurCylinder; // starting cylinder for reduce write current
   uint16   stepRate;
   uint24   landingZone;      // cylinder number of landing zone
   uint8    rpl   :1,
                  :7;
   uint8    rotOffset;        // rotational offset
   uint8          :8;
   uint16   rotRate;          // medium rotation rate
   uint8    reserved[2];
} SCSIGeometryPage;

typedef struct {
   uint8    page     :6,   // page code: 0x08
                     :1,
            ps       :1;
   uint8    len;           // page length 0x0a (0x12 for SCSI-3)
   uint8    rcd      :1,
            mf       :1,
            wce      :1,
                     :5;
   uint8    readPri  :4,   // read retention priority
            writePri :4;   // write retention priority
   uint16   prefetchDisable;// disable pre-fetch transfer length
   uint16   prefetchMin;   // pre-fetch minimum
   uint16   prefetchMax;   // pre-fetch maximum
   uint16   prefetchAbsMax;// absolute pre-fetch maximum
} SCSICachePage;

typedef struct {
   uint8    page  :6,   // page code: 0x08
                  :1,
            ps    :1;
   uint8    len;        // page length 0x16
   uint8          :6,
            lpn   :1,
            nd    :1;
   uint8          :8;
   uint16   maxNotches; // maximum number of notches
   uint16   activeNotch;
   uint32   activeStart;// beginning of active notch
   uint32   activeEnd;  // end of active notch
} SCSINotchPage;

typedef struct {
   uint8    page  :6,   // page code: 0x06
                  :1,
            ps    :1;
   uint8    len;        // page length 0x02
   uint8    rubr  :1,
                  :7;
   uint8          :8;
} SCSIOpticalPage;

typedef struct {
   uint8    page  :6,   // page code: 0x0f
                  :1,
            ps    :1;
   uint8    len;        // page length 0x0e
   uint8          :6,
            dcc   :1,
            dce   :1;
   uint8          :5,
            red   :2,
            dde   :1;
   uint8  compAlg[4];
   uint8  decompAlg[4];
   uint8  reserved[4];
} SCSICompressionPage;

typedef struct {
   uint8    page  :6,   // page code: 0x10
                  :1,
            ps    :1;
   uint8    len;        // page length 0x0e
   uint8    format:5,   // active format
            car   :1,
            cap   :1,
                  :1;
   uint8    partition;  // active partition
   uint8    wbeRatio;   // write buffer empty ratio
   uint8    rbeRatio;   // read buffer empty ratio
   uint16   writeDelay;
   uint8    rew   :1,
            rb0   :1,
            sofc  :2,
            avc   :1,
            rsmk  :1,
            bis   :1,
            dbr   :1;
   uint8    gapSize;
   uint8          :3,
            sew   :1,
            eeg   :1,
            eod   :3;
   uint24   bufSizeAtEW;
   uint8    compression;
   uint8          :8;
} SCSIDeviceConfigPage;

typedef struct {
   uint8    page  :6,   // page code: 0x03
                  :1,
            ps    :1;
   uint8    len;        // page length 0x06
   uint8    unit;       // measurement unit
   uint8          :8;
   uint16   divisor;
   uint16         :16;
} SCSIUnitsPage;


/*
 * Format of START STOP UNIT (0x1b).
 * See sbc3r36 section 5.25 table 91
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;     // 0x1b
   uint8 immed     :1,
         rsvd      :7;
   uint8 reserved;
   uint8 power_mod :4,   // Power Condition Modifier
         reserved1 :4;
   uint8 start     :1,
         loej      :1,   // load/eject
         no_flush  :1,   // Do Not Flush Cache
         reserved2 :1,
         power     :4;   // Power Condition
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIStartStopUnitCmd;

/*
 * Format of ALLOW PREVENT MEDIUM REMOVAL (0x1e).
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;     // 0x1e
   uint8 reserved[3];
   uint8 prevent:2,
                :6;
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIMediumRemovalCmd;

/*
 * Format of READ CAPACITY (10) and (16) request and response blocks.
 * These are defined here because multiple SCSI devices
 * need them.
 *
 * READ CAPACITY (10) command
 * See sbc3r36 section 5.15.1 table 63
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;  // 0x25
   uint8 obslt :1,
               :7;
   uint8 obslt2[4];
   uint8 reserved[2];
   uint8 obslt3:1,
               :7;
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIReadCapacityCmd;

/*
 * READ CAPACITY (10) parameter data (short)
 * See sbc3r36 section 5.15.2 table 64
 */
typedef struct {
   uint32 lbn;
   uint32 blocksize;
} SCSIReadCapacityResponse;

/*
 * READ CAPACITY (16) command
 * See sbc3r36 section 5.16.1 table 65
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;    // 0x9e SERVICE ACTION IN (16)
   uint8 action :5, // 0x10
                :3;
   uint8 obslt[8];
   uint32 len;      // Allocation length
   uint8 obslt2 :1,
                :7;
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIReadCapacity16Cmd;

/*
 * Format of READ CAP(16) response: sbc2r09 (Sec 5.2.12).
 * Old format of the READ CAP(16) response (long)
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint64 lbn;
   uint32 blocksize;
}
#include "vmware_pack_end.h"
SCSIReadCapacity16Response;

/*
 * READ CAPACITY (16) parameter data
 * See sbc3r36 section 5.16.2 table 66
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint64 lbn;                   // Logical Block Address
   uint32 blocksize;             // Logical Block Length
   uint8  prot_en:1,             // protection enable
          p_type:3,              // protection type
          reserved1:4;
   uint8  lbs_exp:4,             // Logical Blocks per exponent
          pi_exp:4;              // Protection interval exponent
   uint8  firstalignedlbahi:6,   // Lowest aligned logical block address (hi 6)
          tprz:1,                // [LBPRZ] logical block provisioning
                                 //         read zeros
          tpe:1;                 // [LBPME] logical block provisioning
                                 //         management enabled
   uint8  firstalignedlbalo;     //Lowest aligned logical block address (low 8)
   uint8  reserved2[16];
}
#include "vmware_pack_end.h"
SCSI3ReadCapacity16Response;

/*
 * Format of SYNCHRONIZE CACHE (10) and (16) request and response blocks.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;  // 0x35
   uint8       :5,
       sync_nv :1,
       immed   :1, // if set return without waiting for sync to complete
               :1;
   uint32     lbn; // block number to begin sync
   uint8       :4,
      grp_num  :4;
   uint16     lbc; // number of blocks to sync, 0 for all blocks starting
                   // from lbn to the last block on the medium
   uint8  control; // control byte
}
#include "vmware_pack_end.h"
SCSISyncCache10Cmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;  // 0x91
   uint8       :5,
       sync_nv :1,
       immed   :1, // if set return, wihout waiting for sync to complete
               :1;
   uint64     lbn; // block number to begin sync
   uint32     lbc; // number of blocks to sync, 0 for all blocks starting
                   // from lbn to the last block on the medium
   uint8       :4,
      grp_num  :4;
   uint8  control; // control byte
}
#include "vmware_pack_end.h"
SCSISyncCache16Cmd;

/*
 * Command structure for a SCSI Unmap command.
 * See sbc3r36 section 5.28.1 table 95
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;           // 0x42
   uint8    anchor      :1,
                        :7;
   uint8    reserved[4];
   uint8    groupNumber :5,
            reserved1   :3;
   uint16   paramListLength;
   uint8    control;
}
#include "vmware_pack_end.h"
SCSIUnmapCmd;

/*
 * UNMAP parameter list header
 * See sbc3r36 section 5.28.2 table 96
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint16   dataLength;
   uint16   blockDescriptorDataLength;
   uint8    reserved1[4];
}
#include "vmware_pack_end.h"
SCSIUnmapParamListHeader;

/*
 * UNMAP block descriptor
 * See sbc3r36 section 5.28.2 table 97
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint64   lba;
   uint32   numBlocks;
   uint8    reserved1[4];
}
#include "vmware_pack_end.h"
SCSIUnmapBlockDescriptor;

/*
 * Format of READ/WRITE (6), (10), (12) and (16)
 * request. These are defined here because multiple SCSI
 * devices need them.
 *
 * Note: In SPC-4/SBC-3 READ(6) and WRITE(6) are obsolete.
 */
typedef SCSICDB6 SCSIReadWrite6Cmd;

#define SCSI_RW10_MAX_LBN         0xffffffffu
#define SCSI_RW10_MAX_LENGTH       0xffffu

typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;  // 0x28
   uint8 rel   :1,
               :2,
         flua  :1,
         dpo   :1,
         lun   :3;
   uint32 lbn;
   uint8 reserved;
   uint16 length;
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIReadWrite10Cmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;  // 0xA8
   uint8 rel   :1,
               :2,
         flua  :1,
         dpo   :1,
         lun   :3;
   uint32 lbn;
   uint32 length;
   uint8 reserved;
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIReadWrite12Cmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;  // 0x88
   uint8 rel   :1,
               :2,
         flua  :1,
         dpo   :1,
               :3;
   uint64 lbn;
   uint32 length;
   uint8 reserved;
   uint8 control;
}
#include "vmware_pack_end.h"
SCSIReadWrite16Cmd;

/*
 * Command structure for a SCSI Reserve command.
 * SCSI2 only - see ANSI X3.131-199x Section 17.2.8 Table 343
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;   // operation code (0x16)
   uint8    ext   :1,
            tid   :3,
            tparty:1,
            lun   :3;
   uint8    resid;
   uint16   extlen;
   uint8    control;
}
#include "vmware_pack_end.h"
SCSIReserveCmd;

/*
 * Command structure for a SCSI Release command.
 * SCSI2 only - see ANSI X3.131-199x Section 17.2.7 Table 342
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;             // (0x17)
   uint8    ext   :1,           // extent-based reservation
            tid   :3,           // 3rd party reservation ID
            tparty:1,           // 3rd party reservation
            lun   :3;
   uint8    resid;              // SCSI-3: reservation ID
   uint8    reserved[2];
   uint8    control;            // control byte
}
#include "vmware_pack_end.h"
SCSIReleaseCmd;

/*
 * SendDiagnostic command
 * See spc4r37 section 6.42 table 320.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;             // (0x1D)
   uint8    uniO  :1,           // unit offline
            devO  :1,           // device offline
            st    :1,           // self-test
                  :1,
            pf    :1,           // page format
            st_code :3;         // Self test code
#define SCSI_ST_CODE_NONE        0 // Default ST
#define SCSI_ST_CODE_BG_SHORT    1 // Background Short ST
#define SCSI_ST_CODE_BG_EXT      2 // Background Extended ST
#define SCSI_ST_CODE_RES         3 // Reserved
#define SCSI_ST_CODE_ABORT_BG_ST 4 // Abort background ST
#define SCSI_ST_CODE_FG_SHORT    5 // Foreground Short ST
#define SCSI_ST_CODE_FG_EXT      6 // Foreground Extened ST
#define SCSI_ST_CODE_RES2        7 // Reserved
   uint8    reserved;
   uint16   length;             // data length
   uint8    control;            // control byte
}
#include "vmware_pack_end.h"
SCSISendDiagnosticCmd;

/*
 * Verify command
 * See ANSI X3.131-199x section 9.2.19 table 143
 * Obsolete - migration to Verify16 recommended
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;             // (0x2f)
   uint8    relAdr  :1,         // relative address
            bytChk  :1,         // byte
            blkvfy  :1,         // blank blocks verification, scsi-3
                    :1,
            dpo     :1,         // cache control bit
            lun     :3;         // logical unit number
   uint32   lbn;                // logical block address
   uint8    reserved;
   uint16   length;             // verification length
   uint8    control;            // control byte
}
#include "vmware_pack_end.h"
SCSIVerify10Cmd;

/*
 * Verify16 command
 * See sbc3r36 section 5.31 table 105
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;              // (0x8f)
   uint8             :1,
            bytChk   :2,         // byte check sbc3r36 5.29 table 98
#define SCSI_VER_BYTE_CHK_FOR_NONE     0x0 // No data out buffer
#define SCSI_VER_BYTE_CHK_FOR_LEN      0x1
#define SCSI_VER_BYTE_CHK_FOR_1_BLK    0x3
                     :1,
            dpo      :1,         // cache control bit
            vrprotect:3;         // VRPROTECT sbc3r36 5.29 table 100,101,102,103
   uint64   lbn;                 // logical block address
   uint32   length;              // verification length
   uint8    grp_num  :5,         // group number (0 = no group)
                     :2,
            restrct  :1;         // restricted for MMC-6
   uint8    control;             // control byte
}
#include "vmware_pack_end.h"
SCSIVerify16Cmd;

/*
 * CD / DVD Event status notification
 * See MMC-6
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8    opcode;              // (0x4A)
   uint8    polled   :1,         // asynchronous or not
                     :7;
   uint8    reserved0[2];
#define SCSI_GESN_CLASS_RSVD0           (1 << 0)
#define SCSI_GESN_CLASS_OP_CHANGE       (1 << 1)
#define SCSI_GESN_CLASS_POW_MGMT        (1 << 2)
#define SCSI_GESN_CLASS_EXT_REQ         (1 << 3)
#define SCSI_GESN_CLASS_MEDIA           (1 << 4)
#define SCSI_GESN_CLASS_MULTI_HOST      (1 << 5)
#define SCSI_GESN_CLASS_DEV_BUSY        (1 << 6)
#define SCSI_GESN_CLASS_RSVD1           (1 << 7)
   uint8    notifyClassReq;      // the class of events we are interested in
   uint8    reserved1[2];
   uint16   length;              // allocation length
   uint8    control;
}
#include "vmware_pack_end.h"
SCSIGetEventStatusNotificationCmd;

/*
 * Format of Persistent Reservation Commands per SPC-3 r23, required for
 * virtualizing reservations.
 */

/* Persistent Reserve IN service actions */
typedef enum {
   READ_KEYS                      = 0x0,
   READ_RESERVATION               = 0x1,
   REPORT_CAPABILITIES            = 0x2,
   READ_FULL_STATUS               = 0x3
} SCSIPersistentReserveInServiceAction;

/*
 * Persistent reservation type codes
 */
typedef enum {
   WRITE_EXCL                     = 0x1,
   EXCL_ACCESS                    = 0x3,
   WRITE_EXCL_REG_ONLY            = 0x5,
   EXCL_ACCESS_REG_ONLY           = 0x6,
   WRITE_EXCL_ALL_REG             = 0x7,
   EXCL_ACCESS_ALL_REG            = 0x8
} SCSIPersistentReserveTypeCode;

typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;             // (0x5E)
   uint8  serviceAction :5,
          reserved      :3;
   uint8  reserved1[5];
   uint16 allocationLength;
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIPersistentReserveInCmd;

/* Persistent Reserve Out Service Actions */
typedef enum {
   REGISTER                          = 0x0,
   PRESERVE                          = 0x1,
   PRELEASE                          = 0x2,
   CLEAR                             = 0x3,
   PREEMPT                           = 0x4,
   PREEMPT_AND_ABORT                 = 0x5,
   REGISTER_AND_IGNORE_EXISTING_KEY  = 0x6,
   REGISTER_AND_MOVE                 = 0x7
} SCSIPersistentReserveOutServiceAction;


typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;             // (0x5F)
   uint8  serviceAction :5,
          reserved      :3;
   uint8  type          :4,
          scope         :4;
   uint8  reserved1[2];
   uint32 parameterListLength;
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIPersistentReserveOutCmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint64 reservationKey;
   uint64 serviceActionResKey;
   uint8  obsolete1[4];
   uint8  aptpl          :1,
          reserved1      :1,
          all_tg_pt      :1,
          spec_i_pt      :1,
          reserved2      :4;
   uint8  reserved3;
   uint8  obsolete2[2];
   /*
    * Per SPC-3 r23, the parameter list length shall be 24 bytes in length if the
    * following are true:
    *  a. the SPEC_I_PT but is set to 0
    *  b. service action is not REGISTER AND MOVE
    *
    * This is currently the only supported mode in the vmkernel,
    * so no additional parameter data is included in this struct
    */
}
#include "vmware_pack_end.h"
SCSIPersistentReserveOutPList;

typedef
#include "vmware_pack_begin.h"
struct {
   uint32 prGeneration;
   uint32 additionalLength;
   uint64 reservationKey;
   uint8  obsolete[4];
   uint8  reserved;
   uint8  type      :4,
          scope     :4;
   uint8 obsolete1[2];
}
#include "vmware_pack_end.h"
SCSIPRReadReservationResp;

/*
 * REQUEST SENSE command
 * See spc4r37 Table 314
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;      // REQUEST SENSE (0x03)
   uint8  desc     :1, // descriptor format sense data
          reserved :7;
   uint16 reserved1;
   uint8  length;      // allocation length (max = 252)
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIRequestSenseCmd;
 
/*
 * Format of the sense data structure maintained in each SCSI
 * device.  Devices should fill in this data structure whenever
 * they return a CHECK status or the 'COMPLETED' sense key
 * for a SCSI command.  The contents are
 * returned to the initiator either through the adapter doing
 * an auto-sense request or the initiator doing an explicit
 * REQUEST SENSE SCSI operation.  A device keeps only one copy
 * of sense data at a time; the base SCSI device support invalidates
 * this data structure before each SCSI operation as needed.
 *
 * See: spc4r37 section 4.5.3 table 53 Fixed format sense data
 *      spc4r37 section 4.5.2.1 table 36 Descriptor format sense data
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 error   :7,
#define SCSI_SENSE_ERROR_CURCMD        0x70      // sense data in fixed format is for "current command"
#define SCSI_SENSE_ERROR_PREVCMD       0x71      // sense data in fixed format is for an earlier command
#define SCSI_SENSE_ERROR_DESC_CURCMD   0x72      // sense data in descriptor format for current command
#define SCSI_SENSE_ERROR_DESC_PREVCMD  0x73      // sense data in descriptor format for an earlier command
         valid   :1;          // info field valid
   union {
      struct {
         uint8 segment;       // segment number
         uint8 key      :4,   // sense key
               sdat_ovfl:1,   // sense data overflow - truncated to fit max len
               ili      :1,   // incorrect length indicator
               eom      :1,   // end-of-medium
               filmrk   :1;   // filemark
         uint8 info[4];       // general information
         uint8 optLen;        // length of optional data that follows
         uint8 cmdInfo[4];    // command-specific information
         uint8 code;          // sense code (ASC)
         uint8 xcode;         // extended sense code (ASCQ)
         uint8 fru;           // field replacable unit code
         uint8 bitpos   :3,
               bpv      :1,
               unused2  :2,
               cd       :1,   // 1 if error in command, 0 if in data
               sksv     :1;   // sense key specific data is valid
         uint16 epos;         // offset of first byte in error

         // Some vendors want to return additional data which
         // requires a sense buffer of up to 64 bytes.
         uint8 additional[46];
      }
/*
 * PACKED PRAGMA on the outer struct should be sufficient as specifying this
 * attribute for struct/union types is equivalent to specifying the packed
 * attribute on each of the struct/union members. But weirdly doesnt seem to
 * work that way hence adding same around each of them.
 */
#include "vmware_pack_end.h"
      fixed;
#include "vmware_pack_begin.h"
      struct {
         uint8 key      :4,
                        :4;
         uint8 code;
         uint8 xcode;
         uint8 reserved:7,
               sdat_ovfl:1;
         uint8 reserved1[2];
         uint8 optLen;
         uint8 additional[56];
      }
#include "vmware_pack_end.h"
      descriptor;
   }format;
}
SCSISenseData;

/**
 * \brief Information Sense Data Descriptor
 * SPC 4 r37, Section 4.5.2.2 table 39
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIInfoSenseDataDesc {
   uint8 type;        //type: 0
   uint8 len;         //len:  0xa
   uint8 reserved  :7,
         valid     :1;
   uint8 reserved1;
   uint8 info[8];
}
#include "vmware_pack_end.h"
SCSIInfoSenseDataDesc;


/**
 * \brief Command specific Information Sense Data Descriptor
 * SPC 4 r37, Section 4.5.2.3 table 40
 */

typedef
#include "vmware_pack_begin.h"
struct SCSICmdSpecificInfoSenseDataDesc {
   uint8 type;      //type: 1
   uint8 len;       //len:  0xa
   uint8 reserved[2];
   uint8 info[8];
}
#include "vmware_pack_end.h"
SCSICmdSpecificInfoSenseDataDesc;

/**
 * \brief Sense Key Specific Sense Data Descriptor
 * SPC 4 r37, Section 4.5.2.4 table 41
 */
typedef
#include "vmware_pack_begin.h"
struct SCSISkeySpecificSenseDataDesc {
   uint8 type;      //type: 2
   uint8 len;       //len:  6
   uint8 reserved[2];
   union {
      struct {          //skey: ILLEGAL_REQUEST
         uint8 bp     :3,
               bpv    :1,
               resv   :2,
               cd     :1,
               sksv   :1;
         uint16  fp;
      } FPInfo;
      struct {          //skey: HARDWARE/MEDIUM/RECOVERED ERROR
         uint8 resv   :7,
               sksv   :1;
         uint16  actRetryCnt;
      } ARCInfo;
      struct {          //skey: NO SENSE/NOT READY
         uint8 resv   :7,
               sksv   :1;
         uint16  progIndication;
      } PIInfo;
      struct {          //skey: COPY ABORTED
         uint8 bp     :3,
               bpv    :1,
               resv   :1,
               sd     :1,
               resv1  :1,
               sksv   :1;
         uint16  fp;
      } SPInfo;
      struct {          //skey: UNIT ATTENTION
         uint8 ovrFlow:1,
               resv   :6,
               sksv   :1;
         uint16  resv1;
      } UAInfo;
   } info;
   uint8 reserved1;
}
#include "vmware_pack_end.h"
SCSISkeySpecificSenseDataDesc;

/**
 * \brief FRU Sense Data Descriptor
 * SPC 4 r37, Section 4.5.2.5 table 48
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIFRUSenseDataDesc {
   uint8 type;      //type: 3
   uint8 len;       //len:  2
   uint8 reserved;
   uint8 fruCode;
}
#include "vmware_pack_end.h"
SCSIFRUSenseDataDesc;

/**
 * \brief Progress Indication Sense Data Descriptor
 * SPC 4 r37, Section 4.5.2.6 table 49
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIProgIndicationSenseDataDesc {
   uint8 type;      //type: 0xa
   uint8 len;       //len:  6
   uint8 aSenseKey;
   uint8 aSenseAsc;
   uint8 aSenseAscq;
   uint8 reserved;
   uint8 progInfo[2];
}
#include "vmware_pack_end.h"
SCSIProgIndicationSenseDataDesc;

/**
 * \brief Forward Sense Data Descriptor
 * SPC 4 r37, Section 4.5.2.7 table 50
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIForwardedSenseDataDesc {
   uint8 type;      //type: 0xc
   uint8 len;
   uint8 senseDataSrc      :4,
             reserved      :3,
             fsdt          :1;
   uint8 fwdStatus;
}
#include "vmware_pack_end.h"
SCSIForwardedSenseDataDesc;

/**
 * \brief Block Commands Sense Data Descriptor
 * SBC 3 r36, Section 4.18.3 table 15
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIBlkCommandsSenseDataDesc {
   uint8 type;      //type: 5
   uint8 len;       //len:  2
   uint8 reserved;
   uint8 reserved1 :5,
         ili       :3,
         reserved2 :1;
   uint8 fwdStatus;
}
#include "vmware_pack_end.h"
SCSIBlkCommandsSenseDataDesc;

/**
 * \brief DABD Sense Data Descriptor
 * SBC 3 r36, Section 4.18.5 table 19
 */

typedef
#include "vmware_pack_begin.h"
struct SCSIDABDSenseDataDesc {
   uint8 type;      //type: 0xb
   uint8 len;
   uint8 reserved1 :5,
         ili       :1,
         reserved2 :1,
         valid     :1;
   uint8 reserved3;
   uint8 sks       :7,
         sksv      :1;
   uint16 sks1;
   uint8 fru;
   uint64 info;
   uint64 cmdInfo;
}
#include "vmware_pack_end.h"
SCSIDABDSenseDataDesc;

/*
 * Read (DVD) Disc Structure definitions.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;
#define SCSI_RDS_MT_DVD  0x0
#define SCSI_RDS_MT_BD   0x1
   uint8  mediaType:4,
                   :4;
   uint32 address;
   uint8  layerNumber;
                                                /* Layer, Address */
#define SCSI_RDS_GDS_AACS_VOLUME_ID        0x80
#define SCSI_RDS_GDS_AACS_MEDIA_SERIAL_NUM 0x81
#define SCSI_RDS_GDS_AACS_MEDIA_ID         0x82
#define SCSI_RDS_GDS_AACS_MEDIA_KEY        0x83 /* Layer number, Pack Number */
#define SCSI_RDS_GDS_LAYERS_LIST           0x90
#define SCSI_RDS_GDS_WRITE_PROTECT         0xC0
#define SCSI_RDS_GDS_CAPABILITY_LIST       0xFF

#define SCSI_RDS_DVD_PHYSICAL_INFO_LEADIN  0x00 /* Layer, - */
#define SCSI_RDS_DVD_COPYRIGHT_INFO_LEADIN 0x01 /* Layer, - */
#define SCSI_RDS_DVD_DISC_KEY              0x02
#define SCSI_RDS_DVD_BURST_CUTTING_AREA    0x03
#define SCSI_RDS_DVD_DISC_MANUFACTURING    0x04 /* Layer, - */
#define SCSI_RDS_DVD_COPYRIGHT_INFO_SECTOR 0x05 /* -, LBA */
#define SCSI_RDS_DVD_MEDIA_ID              0x06
#define SCSI_RDS_DVD_MEDIA_KEY             0x07 /* -, Pack Number */
#define SCSI_RDS_DVD_DVDRAM_DDS_INFO       0x08
#define SCSI_RDS_DVD_DVDRAM_MEDIUM_STATUS  0x09
#define SCSI_RDS_DVD_DVDRAM_SPARE_AREA     0x0A
#define SCSI_RDS_DVD_DVDRAM_RECORDING_TYPE 0x0B
#define SCSI_RDS_DVD_RMD_BORDEROUT         0x0C
#define SCSI_RDS_DVD_RMD_SECTOR            0x0D /* -, Start Field Number of RMA blocks */
#define SCSI_RDS_DVD_PRERECORDED_LEADIN    0x0E
#define SCSI_RDS_DVD_DVDR_MEDIA_ID         0x0F
#define SCSI_RDS_DVD_DVDR_PHYSICAL_INFO    0x10 /* Layer, - */
#define SCSI_RDS_DVD_ADIP_INFO             0x11 /* Layer, - */
#define SCSI_RDS_DVD_HDDVD_CPI             0x12 /* Layer, - */
#define SCSI_RDS_DVD_HDVD_COPYRIGHT_DATA   0x15 /* Layer, Start Copyright Sector */
#define SCSI_RDS_DVD_HDDVDR_MEDIUM_STATUS  0x19
#define SCSI_RDS_DVD_HDDVDR_RMD            0x1A

#define SCSI_RDS_DVD_DL_LAYER_CAPACITY     0x20
#define SCSI_RDS_DVD_DL_MIDDLE_ZONE_START  0x21
#define SCSI_RDS_DVD_DL_JUMP_INTERVAL_SIZE 0x22
#define SCSI_RDS_DVD_DL_MANUAL_LAYER_JUMP  0x23
#define SCSI_RDS_DVD_DL_REMAPPING          0x24 /* -, Anchor Point Number */

#define SCSI_RDS_DVD_DCB_IDENTIFIER        0x30 /* Session Number, Content Descriptor */
#define SCSI_RDS_DVD_MTA_ECC               0x31 /* -, PSN */

#define SCSI_RDS_BD_DI                     0x00
#define SCSI_RDS_BD_DDS                    0x08
#define SCSI_RDS_BD_CARTRIDGE_STATUS       0x09
#define SCSI_RDS_BD_SPARE_AREA             0x0A
#define SCSI_RDS_BD_RAW_DFL                0x12 /* -, Offset */
#define SCSI_RDS_BD_PAC                    0x30 /* -, ID and Format Number */
   uint8  format;
   uint16 length;
   uint8      :6,
          agid:2;
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIReadDiscStructureCmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint16 length;
   uint16 rsvd;
   uint8  partVersion:4,
#define SCSI_RDS_DC_DVD_ROM        0x0
#define SCSI_RDS_DC_DVD_RAM        0x1
#define SCSI_RDS_DC_DVD_R          0x2
#define SCSI_RDS_DC_DVD_RW         0x3
#define SCSI_RDS_DC_HD_DVD_ROM     0x4
#define SCSI_RDS_DC_HD_DVD_RAM     0x5
#define SCSI_RDS_DC_HD_DVD_R       0x6
#define SCSI_RDS_DC_DVD_PLUS_RW    0x9
#define SCSI_RDS_DC_DVD_PLUS_R     0xA
#define SCSI_RDS_DC_DVD_PLUS_RW_DL 0xD
#define SCSI_RDS_DC_DVD_PLUS_R_DL  0xE
          diskCategory:4;
#define SCSI_RDS_MR_1X             0x0
#define SCSI_RDS_MR_2X             0x1
#define SCSI_RDS_MR_4X             0x2
#define SCSI_RDS_MR_8X             0x3
#define SCSI_RDS_MR_16X            0x4
#define SCSI_RDS_MR_UNSPECIFIED    0xF
   uint8  maximumRate:4,
#define SCSI_RDS_DS_120MM          0x0
#define SCSI_RDS_DS_80MM           0x1
          discSize:4;
/* layerType is bitvector */
#define SCSI_RDS_LT_EMBOSSED       0x1
#define SCSI_RDS_LT_RECORDABLE     0x2
#define SCSI_RDS_LT_REWRITEABLE    0x4
   uint8  layerType:4,
          track:1,
#define SCSI_RDS_LAYERS_SL         0x0
#define SCSI_RDS_LAYERS_DL         0x1
          layers:2,
          :1;
#define SCSI_RDS_TD_740NM          0x0
#define SCSI_RDS_TD_800NM          0x1
#define SCSI_RDS_TD_615NM          0x2
#define SCSI_RDS_TD_400NM          0x3
#define SCSI_RDS_TD_340NM          0x4
   uint8  trackDensity:4,
#define SCSI_RDS_LD_267NM          0x0
#define SCSI_RDS_LD_293NM          0x1
#define SCSI_RDS_LD_420NM          0x2
#define SCSI_RDS_LD_285NM          0x4
#define SCSI_RDS_LD_153NM          0x5
#define SCSI_RDS_LD_135NM          0x6
#define SCSI_RDS_LD_353NM          0x8
          linearDensity:4;
#define SCSI_RDS_STARTPSN_DVD      0x030000
#define SCSI_RDS_STARTPSN_DVDRAM   0x031000
#define SCSI_RDS_MAXSIZE_DVD       0xF80000
   uint32 startPSN;
   uint32 endPSN;
   uint32 endPSNLayer0;
   uint8  :7,
          bca:1;
   uint8  rsvd2[2048 - 17];
}
#include "vmware_pack_end.h"
SCSIRDSDVDPhysicalInfoLeadin;


/*
 * MSF structure for CDs.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8     minute;
   uint8     second;
   uint8     frame;
}
#include "vmware_pack_end.h"
SCSICDMSF;


/*
 * ReadCD packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8     opcode;
   uint8     obsolete:1,
             dap:1,
             expectedSectorType:3,
             reserved1:3;
   uint32    lbn;
   uint8     length[3];
   uint8     reserved2:1,
             c2errors:2,
             mainChannelSelectionBits:5;
   uint8     subChannelSelectionBits:3,
             reserved3:5;
   uint8     control;
}
#include "vmware_pack_end.h"
SCSIReadCDCmd;


/*
 * ReadCDMSF packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8     opcode;
   uint8     obsolete:1,
             dap:1,
             expectedSectorType:3,
             reserved1:3;
   uint8     reserved;
   SCSICDMSF start;
   SCSICDMSF end;
   uint8     reserved2:1,
             c2errors:2,
             mainChannelSelectionBits:5;
   uint8     subChannelSelectionBits:3,
             reserved3:5;
   uint8     control;
}
#include "vmware_pack_end.h"
SCSIReadCDMSFCmd;


/*
 * ReadTOC packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8     opcode;
   uint8     reserved1:1,
             msf:1,
             reserved2:6;
   uint8     format:3, /* MMC says 4 bits for eons.  Original ATAPI is only 3 bits. */
             reserved3:5;
   uint8     reserved4[3];
   uint8     trackNumber;
   uint16    allocationLength;
   uint8     control;
}
#include "vmware_pack_end.h"
SCSIReadTOCCmd;


/*
 * ReadSubChannel packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8     opcode;
   uint8     reserved1:1,
             msf:1,
             reserved2:6;
   uint8     reserved3:6,
             subq:1,
             reserved4:1;
   uint8     format;
   uint8     reserved5[2];
   uint8     trackNumber;
   uint16    allocationLength;
   uint8     control;
}
#include "vmware_pack_end.h"
SCSIReadSubChannelCmd;


/*
 * PlayMSF packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8     opcode;
   uint8     reserved[2];
   SCSICDMSF start;
   SCSICDMSF end;
   uint8     control;
}
#include "vmware_pack_end.h"
SCSIPlayMSFCmd;


/*
 * SetStreaming packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;
   uint8  reserved1:5,
          reserved2:3;
   uint8  reserved3[7];
   uint16 parameterListLength;
   uint8  control;
}
#include "vmware_pack_end.h"
SCSISetStreamingCmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint8  ra:1,            // optimize for switching between reads and writes
          exact:1,         // support exact performance request
          rdd:1,           // restore logical unit defaults
          reserved1:5;
   uint8  reserved2[3];
   uint32 start;           // first LBA
   uint32 end;             // last LBA
   uint32 readSize;        // number of KB per readTime 
   uint32 readTime;        // number of ms for one readSize
   uint32 writeSize;       // number of KB per writeTime
   uint32 writeTime;       // number of ms for one writeSize
}
#include "vmware_pack_end.h"
SCSISSPerformanceDescriptor;


/*
 * SetReadAhead packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8  opcode;         // (0xA7)
   uint8  reserved1:5,
          reserved2:3;
   uint32 trigger;        // when this LBA is read, read-ahead at readAhead
   uint32 readAhead;      // LBA at which read-ahead should begin
   uint8  control;
}
#include "vmware_pack_end.h"
SCSISetReadAheadCmd;


/*
 * GetPerformance packet data.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint8 opcode;           // (0xAC)
#define SCSI_GP_EXCEPTIONS_NONE 0x0
#define SCSI_GP_EXCEPTIONS_ALL  0x1
#define SCSI_GP_EXCEPTIONS_SOME 0x2
   uint8  exceptions:2,    // report nominal performance or exceptions
          write:1,         // report write performance
          tolerance:2,     // report performance with some tolerance
          reserved1:3;
   uint32 start;           // starting LBA for performance data
   uint8  reserved2[2];
   uint16 maxDescriptors;  // maximum number of performance descriptors
   uint8  reserved3;
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIGetPerformanceCmd;

typedef
#include "vmware_pack_begin.h"
struct {
   uint32 dataLen;         // length of data to follow
   uint8  exceptions:1,    // reported performance is for exceptions
          write:1,         // reported performance is for writes
          reserved1:6;
   uint8  reserved2[3];
}
#include "vmware_pack_end.h"
SCSIGetPerfResponseHeader;

typedef
#include "vmware_pack_begin.h"
struct {
   uint32 startLBA;       // first LBA tracked by this descriptor
   uint32 startPerf;      // performance (KB/s) at startLBA
   uint32 endLBA;         // last LBA tracked by this descriptor
   uint32 endPerf;        // performance (KB/s) at endLBA
}
#include "vmware_pack_end.h"
SCSIGetPerfResponseNominal;

typedef
#include "vmware_pack_begin.h"
struct {
   uint32 lba;            // there exists a seek delay between LBA - 1 and LBA
   uint16 time;           // expected additional delay (tenths of ms)
}
#include "vmware_pack_end.h"
SCSIGetPerfResponseException;


/*
 * Definitions for MMC Features and Profiles. See MMC-2, Section 5 for details.
 * The response to a GET CONFIGURATION (0x46) command consists of a Feature
 * Header with zero or more Feature Descriptors.
 */

/*
 * Feature Header.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   uint32 length;
   uint8  reserved[2];
   uint16 currentProfile;
}
#include "vmware_pack_end.h"
SCSIFeatureHeader;


/*
 * Feature Descriptor generic format.
 */
typedef
#include "vmware_pack_begin.h"
struct {
#define SCSI_FEAT_CODE_PROFILELIST         0x0
#define SCSI_FEAT_CODE_CORE                0x1
#define SCSI_FEAT_CODE_MORPHING            0x2
#define SCSI_FEAT_CODE_REMOVABLEMEDIUM     0x3
#define SCSI_FEAT_CODE_RANDOMREADABLE      0x10
#define SCSI_FEAT_CODE_DVDREAD             0x1F
#define SCSI_FEAT_CODE_POWERMANAGEMENT     0x100
#define SCSI_FEAT_CODE_TIMEOUT             0x105
#define SCSI_FEAT_CODE_REALTIMESTREAMING   0x107
#define SCSI_FEAT_CODE_VMWARE_LAST         0xFF80
   uint16 code;
   uint8  featureCurrent:1,
          persistent:1,
          version:4,
          reserved:2;
   uint8  additionalLength;
   /* Feature Dependent Data to follow. */
}
#include "vmware_pack_end.h"
SCSIFeatureDescriptor;

/*
 * Profile Descriptor format.
 *
 * Zero or more of these follow the Profile List Feature Descriptor, which
 * matches the generic Feature Descriptor format described above.
 */
typedef
#include "vmware_pack_begin.h"
struct {
#define SCSI_PROFILE_NUMBER_DVDROM 0x10
   uint16 number;
   uint8  profileCurrent:1,
          reserved0:7;
   uint8  reserved1;
}
#include "vmware_pack_end.h"
SCSIProfileDescriptor;


/*
 * Many Feature Descriptors consist of nothing more than the generic Feature
 * Descriptor format defined earlier; those that are larger are defined below.
 */

/*
 * Core Feature Descriptor format.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   SCSIFeatureDescriptor feature;
#define SCSI_CORE_PHY_ATAPI 0x2
   uint32                phy;
}
#include "vmware_pack_end.h"
SCSICoreFeatureDescriptor;


/*
 * Morphing Descriptor format.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   SCSIFeatureDescriptor feature;
   uint8 async:1,
         reserved0:7;
   uint8 reserved1;
   uint8 reserved2;
   uint8 reserved3;
}
#include "vmware_pack_end.h"
SCSIMorphingFeatureDescriptor;


/*
 * Removable Medium Descriptor format.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   SCSIFeatureDescriptor feature;
   uint8                 lock:1,
                         reserved0:1,
                         preventJumper:1,
                         eject:1,
                         reserved1:1,
#define SCSI_REMOVABLE_MEDIUM_TYPE_TRAY 0x1
                         loadingMechanismType:3;
   uint8                 reserved2;
   uint8                 reserved3;
   uint8                 reserved4;
}
#include "vmware_pack_end.h"
SCSIRemovableMediumFeatureDescriptor;


/*
 * Random Readable Descriptor format.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   SCSIFeatureDescriptor feature;
   uint32                logicalBlockSize;
#define SCSI_RANDOM_READABLE_BLOCKING_DVD 0x10
   uint16                blocking;
   uint8                 pagePresent:1,
                         reserved0:7;
   uint8                 reserved1;
}
#include "vmware_pack_end.h"
SCSIRandomReadableFeatureDescriptor;


/*
 * VMware Last Descriptor format. This is a VMware-specific feature descriptor
 * designed to work around a Windows XP SP3 bug where the last eight bytes of
 * a GET CONFIGURATION response are ignored by the guest driver. It does so by,
 * well, occupying the last eight bytes of our emulation's response to a
 * GET CONFIGURATION request.
 */
typedef
#include "vmware_pack_begin.h"
struct {
   SCSIFeatureDescriptor feature;
   uint8 garbage[4];
}
#include "vmware_pack_end.h"
SCSIVMwareLastFeatureDescriptor;

/**
 * \brief Format of ReceiveCopyResults cmd as per 
 *        SPC4 r24 section 6.18.1 table 200.
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIReceiveCopyResultsCmd {   
   uint8  opcode;               // receive_copy_results (0x84)
   uint8  serviceAction:5,      // service action
          reserved:3;           // Reserved
   uint8  listID;               // list identifier
   uint8  reserved1[7];
   uint32 length;               // allocation length
   uint8  reserved2;
   uint8  control;
}
#include "vmware_pack_end.h"
SCSIReceiveCopyResultsCmd;

#define SCSI_SERVICE_ACTION_OPERATING_PARAMS 0x03       

/**
 * \brief Format of ReceiveCopyResults response for service action OPERATING
 *        PARAMETERS as per SPC4 r24 section 6.18.4 table 206.
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIReceiveCopyResultsSrvAction03Response {
   uint32 availData;            // available data (n-3)
   uint8  SNLid:1,              // SNLID bit
          reserved:7;
   uint8  reserved2[3];
   uint16 maxTargetDescCnt;     // Maximum target descriptor count
   uint16 maxSegmentDescCnt;    // Maximum segment descriptor count
   uint32 maxDescListLen;       // Maximum descriptor list length
   uint32 maxSegmentLen;        // Maximum segment length
   uint32 maxInlineDataLen;     // Maximum inline data length
   uint32 heldDataLimit;        // Held data limit
   uint32 maxStreamDevXferSize; // Maximum stream device transfer size
   uint16 reserved3;
   uint16 totalConcrrCopies;    // Total concurrent copies
   uint8  maxConcrrCopies;      // Maximum concurrent copies
   uint8  lgDataSegGran;        // Data segment granularity (log 2)
   uint8  lgInlineDataGran;     // Inline data granularity (log 2)
   uint8  lgHeldDataGran;       // Held data granularity (log 2)
   uint8  reserved4[3];
   uint8  ImplDescListLen;      // Implemented descriptor list length (n-43)
}
#include "vmware_pack_end.h"
SCSIReceiveCopyResultsSrvAction03Response;

/*
 * Host and device status definitions.
 *
 * These mimic the BusLogic adapter-specific definitions but are
 * intended to be adapter-independent (i.e. adapters that don't
 * define these values directly or define them with different values
 * must map them to known values).
 */

/*
 * host adapter status/error codes
 */
typedef enum {
   BTSTAT_SUCCESS       = 0x00,  // CCB complete normally with no errors
   BTSTAT_LINKED_COMMAND_COMPLETED           = 0x0a,
   BTSTAT_LINKED_COMMAND_COMPLETED_WITH_FLAG = 0x0b,
   BTSTAT_DATA_UNDERRUN = 0x0c,
   BTSTAT_SELTIMEO      = 0x11,  // SCSI selection timeout
   BTSTAT_DATARUN       = 0x12,  // data overrun/underrun
   BTSTAT_BUSFREE       = 0x13,  // unexpected bus free
   BTSTAT_INVPHASE      = 0x14,  // invalid bus phase or sequence requested by target
   BTSTAT_INVCODE       = 0x15,  // invalid action code in outgoing mailbox
   BTSTAT_INVOPCODE     = 0x16,  // invalid operation code in CCB
   BTSTAT_LUNMISMATCH   = 0x17,  // linked CCB has different LUN from first CCB
   BTSTAT_INVPARAM      = 0x1a,  // invalid parameter in CCB or segment list
   BTSTAT_SENSFAILED    = 0x1b,  // auto request sense failed
   BTSTAT_TAGREJECT     = 0x1c,  // SCSI II tagged queueing message rejected by target
   BTSTAT_BADMSG        = 0x1d,  // unsupported message received by the host adapter
   BTSTAT_HAHARDWARE    = 0x20,  // host adapter hardware failed
   BTSTAT_NORESPONSE    = 0x21,  // target did not respond to SCSI ATN, sent a SCSI RST
   BTSTAT_SENTRST       = 0x22,  // host adapter asserted a SCSI RST
   BTSTAT_RECVRST       = 0x23,  // other SCSI devices asserted a SCSI RST
   BTSTAT_DISCONNECT    = 0x24,  // target device reconnected improperly (w/o tag)
   BTSTAT_BUSRESET      = 0x25,  // host adapter issued BUS device reset
   BTSTAT_ABORTQUEUE    = 0x26,  // abort queue generated
   BTSTAT_HASOFTWARE    = 0x27,  // host adapter software error
   BTSTAT_HATIMEOUT     = 0x30,  // host adapter hardware timeout error
   BTSTAT_SCSIPARITY    = 0x34,  // SCSI parity error detected
} HostBusAdapterStatus;

// scsi device status values
typedef enum {
   SDSTAT_GOOD                    = 0x00, // no errors
   SDSTAT_CHECK                   = 0x02, // check condition
   SDSTAT_CONDITION_MET           = 0x04, // condition met
   SDSTAT_BUSY                    = 0x08, // device busy
   SDSTAT_INTERMEDIATE            = 0x10,
   SDSTAT_INTERMEDIATE_CONDITION  = 0x14,
   SDSTAT_RESERVATION_CONFLICT    = 0x18, // device reserved by another host
   SDSTAT_COMMAND_TERMINATED      = 0x22,
   SDSTAT_TASK_SET_FULL           = 0x28,
   SDSTAT_ACA_ACTIVE              = 0x30,
   SDSTAT_TASK_ABORTED            = 0x40,
} SCSIDeviceStatus;

typedef enum {
   SCSI_XFER_AUTO     = 0,    // transfer direction depends on opcode
   SCSI_XFER_TOHOST   = 1,    // data is from device -> adapter
   SCSI_XFER_TODEVICE = 2,    // data is from adapter -> device
   SCSI_XFER_NONE     = 3     // data transfer is suppressed
} SCSIXferType;

typedef enum {
   SCSI_EMULATE               = 0,   // emulate this command
   SCSI_DONT_EMULATE          = 1,   // do not emulate this command but log a message
   SCSI_DONT_EMULATE_DONT_LOG = 2    // do not emulate this command or log a message
} SCSIEmulation;

#define HBA_SCSI_ID  7                    //default HBA SCSI ID

/**
 * \brief Write Same Command
 * SBC 3 r36, Section 5.43 (Table 119)
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIWriteSame10Cmd {
   /** \Command opcode - 0x41 */
   uint8    opcode;
   /** \Unused */
   uint8    reserved1:3;
   /** \Unmap request */
   uint8    unmap:1;
   /** \resource provisioning */
   uint8    anchor:1;
   /** \protection information */
   uint8    wrProtect:3;
   /** \Start LBA for the request*/
   uint32   lba;
   /** \Group number of the command */
   uint8    groupNumber:5;
   /** \Unused */
   uint8    reserved3:3;
   /** \Number of blocks to unmap/write same request*/
   uint16   numBlocks;
   /** \Control byte */
   uint8    control;
}
#include "vmware_pack_end.h"
SCSIWriteSame10Cmd;

/**
 * \brief Write Same Command
 * SBC 3 r36, Section 5.44 (Table 121)
 */
typedef
#include "vmware_pack_begin.h"
struct SCSIWriteSame16Cmd {
   /** \Command opcode - 0x93 */
   uint8    opcode;
   /** \No data out buffer */
   uint8    ndob:1;
   /** \Unused */
   uint8    reserved1:2;
   /** \Unmap request */
   uint8    unmap:1;
   /** \Resource provisioning */
   uint8    anchor:1;
   /** \Protection information */
   uint8    wrProtect:3;
   /** \Start LBA for the request */
   uint64   lba;
   /** \Number of blocks to unmap/write same request */
   uint32   numBlocks;
   /** \Group number of the command */
   uint8    groupNumber:5;
   /** \Unused */
   uint8    reserved2:3;
   /** \Control byte */
   uint8    control;
}
#include "vmware_pack_end.h"
SCSIWriteSame16Cmd;

#define SCSI_XCOPY_NOLISTID 0x3

/**
 * SCSI extended copy parameter list header. Modified in SPC-4 r24 , Section
 * 6.3.1 table 101 
 */
typedef 
#include "vmware_pack_begin.h"
struct SCSIExtendedCopyParamListHeader {
   /** \brief see above spc section */
   uint8    listID;
   /** \brief see above spc section */
   uint8    priority:3,
   /** \brief see above spc section */
            LIDU:2,
   /** \brief see above spc section */
            STR:1,
   /** \brief see above spc section */
            reserved2:2;
   /** \brief see above spc section */
   uint16   targetDescriptorListLength;
   /** \brief see above spc section */
   uint8    reserved3[4];
   /** \brief see above spc section */
   uint32   segmentDescriptorListLength;
   /** \brief see above spc section */
   uint32   inlineDataLength;
} 
#include "vmware_pack_end.h"
SCSIExtendedCopyParamListHeader;

/**
 * See SPC-4 r24 Section 6.3.6.2 Table 56 and Section 6.3.7.5 Table 66 
 */
#define SCSI_TARGET_DESCTYPE_ID        0xe4
#define SCSI_SEGMENT_DESCTYPE_BB_LEN   0x18
#define SCSI_SEGMENT_DESCTYPE_BOBO_LEN 0x1c
typedef enum {
   SCSI_SEGMENT_DESCTYPE_BB = 0x02,
   SCSI_SEGMENT_DESCTYPE_BOBO = 0x0a,
} XcopySegType;

#define SCSI_SEGMENT_DESCTYPE_BB_MAX_LENB ((1 << 25) - (1 << 21)) //30MB
#define SCSI_SEGMENT_DESCTYPE_BOBO_MAX_LENB ((1UL << 32) - (1 << 21)) //4094MB
#define SCSI_SEGMENT_DESCTYPE_BB_MAX_DESC 8
#define SCSI_SEGMENT_DESCTYPE_BOBO_MAX_DESC 1
#define SCSI_XCOPY_MAX_LEN_WITH_BB (SCSI_SEGMENT_DESCTYPE_BB_MAX_LENB * \
                                    SCSI_SEGMENT_DESCTYPE_BB_MAX_DESC)
#define SCSI_XCOPY_MAX_LEN_WITH_BOBO (SCSI_SEGMENT_DESCTYPE_BOBO_MAX_LENB * \
                                      SCSI_SEGMENT_DESCTYPE_BOBO_MAX_DESC)


/**
 * Verify and Write(ATS) 16-byte command 
 * SBC-3 r23, Section 5.2 Table 23. 
 */ 
typedef 
#include "vmware_pack_begin.h"
struct SCSIVerifyAndWrite16 {
   /** SCSI_ATS_OPCODE - 0x89h */
   uint8     opcode;
   uint8     reserved1 :1,
             fua_nv    :1,
             reserved2 :1,
             fua       :1,
             dpo       :1,
             wrprotect :3;
   /** Starting block for data comparison */
   uint64    lba;
   uint8     reserved3[3];
   /** Count of the number of blocks that are compared */
   uint8     num_blocks;
   uint8     group_number :5,
             reserved4    :3;
   uint8     control;
} 
#include "vmware_pack_end.h"
SCSIVerifyAndWrite16;

/**
 * SCSI ATA Pass-Through command as described in T10 04-262r8
 * http://www.t10.org/ftp/t10/document.04/04-262r8.pdf
 *
 * ATA Specific commands/subcommands are described in
 * "ATA/ATAPI Command Set - 3 (ACS-3) T13/2161-D, Revision 5,
 * 28 October, 2013
 */
#define SCSI_ATA_PASSTHROUGH_BUF_LEN     512

/*
 * SMART Command Transport (SCT) related defines.
 */
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_COMMAND 0x4
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FEATURE_SET_GET_WRITE_CACHE_STATE 0x1
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FUNCTION_SET_STATE_AND_OPTIONS 0x1
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FUNCTION_GET_STATE 0x2
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FUNCTION_GET_OPTIONS 0x3
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_DELEGATE_TO_SET_FEATURES 0x1
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_ENABLE_WRITE_CACHE 0x2
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_DISABLE_WRITE_CACHE 0x3
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FEATURE_STATE_VOLATILITY_BIT 0x1
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FEATURE_OPTION_RESTORE_DEFAULT 0x0
#define SCSI_ATA_SCT_SET_FEATURE_CONTROL_FEATURE_OPTION_PRESERVE_STATE 0x1

typedef
#include "vmware_pack_begin.h"
struct SCSIATASCTFeatureControlKeyPage {
   uint16   actionCode;
   uint16   functionCode;
   uint16   featureCode;
   uint16   state;
   uint16   options;
}
#include "vmware_pack_end.h"
SCSIATASCTFeatureControlKeyPage;

typedef
#include "vmware_pack_begin.h"
struct SCSIATASenseBufferStatusReturnDescriptor {
   uint8    descriptorCode;
   uint8    additionalDescriptorLength;
   uint8    extend    :1,
            reserved  :7;
   uint8    error;
   uint8    sectorCountHO;
   uint8    sectorCount;
   uint8    lbaLowHO;
   uint8    lbaLow;
   uint8    lbaMidHO;
   uint8    lbaMid;
   uint8    lbaHighHO;
   uint8    lbaHigh;
   uint8    device;
   uint8    status;
}
#include "vmware_pack_end.h"
SCSIATASenseBufferStatusReturnDescriptor;

typedef
#include "vmware_pack_begin.h"
struct SCSIATASCTFeatureControlGetCommandStatusResponse {
   uint16   formatVersion;
   uint16   SCTVersion;
   uint16   reserved1;
   uint32   statusFlags;
   uint8    deviceState;
   uint8    reserved2[3];
   uint16   extendedStatus;
   uint16   actionCode;
   uint16   functionCode;
   uint8    reserved3[20];
   uint64   lba;
   uint8    reserved4[152];
   uint8    hdaTemp;
   uint8    minTemp;
   uint8    maxTemp;
   uint8    lifeMinTemp;
   uint8    lifeMaxTemp;
   uint16   reserved5;
   uint32   overLimitCount;
   uint32   underLimitCount;
   uint8    reserved6[266];
   uint8    vendorSpecific[32];
}
#include "vmware_pack_end.h"
SCSIATASCTFeatureControlGetCommandStatusResponse;

typedef
#include "vmware_pack_begin.h"
struct SCSIATAPassThrough16Cmd {
   uint8    opcode;
#define SCSI_CMD_ATA_PASSTHROUGH_16      0x85
   uint8    extend    :1,
            protocol  :4,
#define SCSI_ATA_PROTOCOL_NONDATA        0x3
#define SCSI_ATA_PROTOCOL_PIO_DATAIN     0x4
#define SCSI_ATA_PROTOCOL_PIO_DATAOUT    0x5
#define SCSI_ATA_PROTOCOL_DMA            0x6
#define SCSI_ATA_PROTOCOL_UDMA_DATAIN    0xa
#define SCSI_ATA_PROTOCOL_UDMA_DATAOUT   0xb
            mc        :3;
   uint8    tlen      :2,
            byteblock :1, // 0-transfer bytes, 1-transfer blocks
            tdir      :1, // 0-copy to device, 1-copy from device
            reserved1 :1,
            ckcond    :1,
            offline   :2;
   uint16   feature;
#define SCSI_ATA_FEATURE_TRIM            0x01
#define SCSI_ATA_SMART_READ_VALUES       0xd0
#define SCSI_ATA_SMART_READ_THRESHOLDS   0xd1
#define SCSI_ATA_SMART_READ_LOG          0xd5
#define SCSI_ATA_SMART_WRITE_LOG         0xd6
#define SCSI_ATA_SMART_ENABLE            0xd8
#define SCSI_ATA_SMART_DISABLE           0xd9
#define SCSI_ATA_SMART_STATUS            0xda
#define SCSI_ATA_SET_FEATURE             0xef
#define SCSI_ATA_FLUSH_CACHE             0xe7
   uint16   sectorcount;
   uint16   lba_low;
#define SCSI_ATA_SCT_COMMAND_STATUS_LOG_LBA 0xE0
#define SCSI_ATA_SCT_DATA_XFER_LOG_LBA      0xE1
   uint16   lba_mid;
   uint16   lba_high;
   uint8    device;
   uint8    cmd;          // ATA5 7.52.1
#define SCSI_ATA_DSM_CMD                 0x06
#define SCSI_ATA_SMART_CMD               0xb0
#define SCSI_ATA_WC_ENABLE               0x02
#define SCSI_ATA_WC_DISABLE              0x82
#define SCSI_ATA_IDENTIFY_CMD            0xec
   uint8    ctrl;
}
#include "vmware_pack_end.h"
SCSIATAPassThrough16Cmd;

/*
 *---------------------------------------------------------------------------
 *
 * SCSICdb_IsRead --
 *
 *      This function returns TRUE if the scsi command passed as an argument is
 *      a read.
 *
 * Results:
 *      TRUE/FALSE
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

static INLINE Bool
SCSICdb_IsRead(uint8 cdb0)        // IN
{
   return cdb0 == SCSI_CMD_READ6
       || cdb0 == SCSI_CMD_READ10
       || cdb0 == SCSI_CMD_READ12
       || cdb0 == SCSI_CMD_READ16;
}


/*
 *---------------------------------------------------------------------------
 *
 * SCSICdb_IsWrite --
 *
 *      This function returns TRUE if the scsi command passed as an argument is
 *      a write.
 *
 * Results:
 *      TRUE/FALSE
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

static INLINE Bool
SCSICdb_IsWrite(uint8 cdb0)       // IN
{
   return cdb0 == SCSI_CMD_WRITE6
       || cdb0 == SCSI_CMD_WRITE10
       || cdb0 == SCSI_CMD_WRITE12
       || cdb0 == SCSI_CMD_WRITE16;
}


/*
 *---------------------------------------------------------------------------
 *
 * SCSICdb_ModifiesMedia --
 *
 *      This function returns TRUE if the scsi command passed as an argument
 *      changes the storage medium
 *
 *      XXX PR 520576 This list needs to be expanded upon in order accurately
 *                    represent all command types that modify the underlying
 *                    storage medium
 *
 * Results:
 *      TRUE/FALSE
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

static INLINE Bool
SCSICdb_ModifiesMedia(uint8 cdb0)       // IN
{
   return SCSICdb_IsWrite(cdb0) ||
          cdb0 == SCSI_CMD_WRITE_SAME16 ||
          cdb0 == SCSI_CMD_UNMAP;
}

/*
 *---------------------------------------------------------------------------
 *
 * SCSICdb_IsRW --
 *
 *      This function returns TRUE if the scsi command passed as an argument is
 *      a read or write.
 *
 * Results:
 *      TRUE/FALSE
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

static INLINE Bool
SCSICdb_IsRW(uint8 cdb0)        // IN
{
   return SCSICdb_IsRead(cdb0) || SCSICdb_IsWrite(cdb0);
}


/*
 *---------------------------------------------------------------------------
 *
 * SCSICdb_GetCDBLength --
 *
 *      This function returns length of specified command.  Multibyte
 *      CDB (0x7F) is reported as reserved command.
 *
 * Results:
 *      6 for commands 00-1F
 *      10 for commands 20-5F
 *      16 for commands 80-9F
 *      12 for commands A0-BF
 *      SCSI_GRP_RESERVED for commands 60-7F
 *      SCSI_GRP_VENDOR for commands C0-FF
 *         Both SCSI_GRP_RESERVED & SCSI_GRP_VENDOR are guarateed to have
 *         bigger value than 16.
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

#define SCSI_GRP_RESERVED  64
#define SCSI_GRP_VENDOR    65

static INLINE size_t
SCSICdb_GetCDBLength(uint8 cdb0)    // IN
{
   static const unsigned char lengths[] = {
      6,                 /* 00 - 1F */
      10,                /* 20 - 3F */
      10,                /* 40 - 5F */
      SCSI_GRP_RESERVED, /* 60 - 7F */
      16,                /* 80 - 9F */
      12,                /* A0 - BF */
      SCSI_GRP_VENDOR,   /* C0 - DF */
      SCSI_GRP_VENDOR,   /* E0 - FF */
   };

   return lengths[cdb0 >> 5];
}


/*
 *---------------------------------------------------------------------------
 * 
 * SCSICdb_GetLengthFieldOffset --
 *
 *      Returns the offset in bytes of the 'length' field in the CDB
 *      of a given command.
 *
 * Results:
 *      Offset of 'length' field.
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

static INLINE uint16
SCSICdb_GetLengthFieldOffset(uint8 cmd)
{
   switch (cmd) {
   case SCSI_CMD_READ10:
   case SCSI_CMD_WRITE10:
      return offsetof(SCSIReadWrite10Cmd, length);
   case SCSI_CMD_READ6:
   case SCSI_CMD_WRITE6:
      return offsetof(SCSIReadWrite6Cmd, length);
   case SCSI_CMD_READ16:
   case SCSI_CMD_WRITE16:
      return offsetof(SCSIReadWrite16Cmd, length);
   case SCSI_CMD_READ12:
   case SCSI_CMD_WRITE12:
      return offsetof(SCSIReadWrite12Cmd, length);
   case SCSI_CMD_UNMAP:
      return offsetof(SCSIUnmapCmd, paramListLength);
   default:
      return 0;
   }
}

/*
 *---------------------------------------------------------------------------
 *
 * SCSI3InquiryLen --
 *
 *      Returns 16-bit allocation length specified in SCSI3 Inquriy CMD cmd
 *
 * Results:
 *      16-bit allocation length.
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */

static INLINE uint16
SCSI3InquiryLen(const SCSI3InquiryCmd *inqCmd)     // IN
{
  return (inqCmd->lengthMSB << 8) + inqCmd->length;
}

/*
 *---------------------------------------------------------------------------
 *
 * SCSI_IsFixedSense --
 *
 *      Check if the sense information is in fixed sense format
 *
 * Results:
 *      TRUE - if fixed sense format.
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */
static INLINE Bool
SCSI_IsFixedSense(SCSISenseData *sense)
{
   return (sense->error == SCSI_SENSE_ERROR_CURCMD ||
           sense->error == SCSI_SENSE_ERROR_PREVCMD);
}

/*
 *---------------------------------------------------------------------------
 *
 * SCSI_IsDescSense --
 *
 *      Check if the sense information is in descriptor sense format
 *
 * Results:
 *      TRUE - if descriptor sense format.
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */
static INLINE Bool
SCSI_IsDescSense(SCSISenseData *sense)
{
   return (sense->error == SCSI_SENSE_ERROR_DESC_CURCMD ||
           sense->error == SCSI_SENSE_ERROR_DESC_PREVCMD);
}

/*
 *---------------------------------------------------------------------------
 *
 * SCSI_ExtractSenseData --
 *
 *      Extracts sense key/asc/ascq from the sense buffer provided
 *
 * Results:
 *      TRUE - if extraction successful.
 *      FALSE - if extraction unsuccessful.
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */
static INLINE Bool
SCSI_ExtractSenseData(SCSISenseData *sense,
                      uint8 *skey,
                      uint8 *asc,
                      uint8 *ascq)
{
   switch(sense->error) {
      case SCSI_SENSE_ERROR_CURCMD:
      case SCSI_SENSE_ERROR_PREVCMD:
         if (skey) {
            *skey = sense->format.fixed.key;
         }
         if (asc) {
            *asc = (sense->format.fixed.optLen >= 5) ? sense->format.fixed.code : 0;
         }
         if (ascq) {
            *ascq = (sense->format.fixed.optLen >= 6) ? sense->format.fixed.xcode : 0;
         }
         break;
      case SCSI_SENSE_ERROR_DESC_CURCMD:
      case SCSI_SENSE_ERROR_DESC_PREVCMD:
         if (skey) {
            *skey = sense->format.descriptor.key;
         }
         if (asc) {
            *asc = sense->format.descriptor.code;
         }
         if (ascq) {
            *ascq = sense->format.descriptor.xcode;
         }
         break;
      default:
         if (skey) {
            *skey = 0;
         }
         if (asc) {
            *asc = 0;
         }
         if (ascq) {
            *ascq = 0;
         }
         return FALSE;
   }
   return TRUE;
}

/*
 *---------------------------------------------------------------------------
 *
 * SCSI_SetSense --
 *
 *      Populate sense buffer with given error/sensekey/asc/ascq
 *
 * Side effects:
 *      None.
 *
 *---------------------------------------------------------------------------
 */
static INLINE void
SCSI_SetSense(SCSISenseData *sense,
              uint8 error,
              uint8 skey,
              uint8 asc,
              uint8 ascq)
{
   if (sense == NULL) {
      return;
   }

   sense->error = error;
   switch(error) {
      case SCSI_SENSE_ERROR_CURCMD:
      case SCSI_SENSE_ERROR_PREVCMD:
         sense->format.fixed.key = skey;
         sense->format.fixed.code = asc;
         sense->format.fixed.xcode = ascq;
         sense->format.fixed.fru = 0;
         sense->format.fixed.bitpos = 0;
         sense->format.fixed.bpv = 0;
         sense->format.fixed.cd = 0;
         sense->format.fixed.sksv = 0;
         sense->format.fixed.epos = 0;
         sense->format.fixed.optLen = 10;
         break;
      case SCSI_SENSE_ERROR_DESC_CURCMD:
      case SCSI_SENSE_ERROR_DESC_PREVCMD:
         sense->format.descriptor.key = skey;
         sense->format.descriptor.code = asc;
         sense->format.descriptor.xcode = ascq;
         break;
      default:
         return;
   }
   return;
}

typedef
#include "vmware_pack_begin.h"
struct SCSICmdInfo {
   uint8 code;
   uint8 xferType;
   const char *name;
   uint8 emulation;
}
#include "vmware_pack_end.h"
SCSICmdInfo;

/* This array contains the data below defined in SCSI_CMD_INFO_DATA, but
 * can't assign the data here because it would be included in all .o, so
 * it should be initialized in one .o file for each part of the product.
 * In vmm, this is currently initialized in buslogicMdev.c.
 * In vmx, this is currently initialized in usbAnalyzer.c.
 * In vmkernel, this is currently initialized in vmk_scsi.c.
 */
extern SCSICmdInfo scsiCmdInfo[256];
#define SCSI_CMD_GET_CODE(cmd)     (scsiCmdInfo[cmd].code)
#define SCSI_CMD_GET_XFERTYPE(cmd) (scsiCmdInfo[cmd].xferType)
#define SCSI_CMD_GET_NAME(cmd)     (scsiCmdInfo[cmd].name)
#define SCSI_CMD_GET_EMULATION(cmd) (scsiCmdInfo[cmd].emulation)

#define SCSI_CMD_INFO_DATA \
   {SCSI_CMD_TEST_UNIT_READY,  SCSI_XFER_NONE,     "TEST UNIT READY", SCSI_EMULATE}, \
   {SCSI_CMD_REZERO_UNIT,      SCSI_XFER_NONE,     "REWIND/REZERO UNIT", SCSI_DONT_EMULATE}, \
   {0x02,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_REQUEST_SENSE,    SCSI_XFER_TOHOST,   "REQUEST SENSE", SCSI_EMULATE}, \
   {SCSI_CMD_FORMAT_UNIT,      SCSI_XFER_TODEVICE, "FORMAT UNIT", SCSI_EMULATE}, \
   {SCSI_CMD_READ_BLOCKLIMITS, SCSI_XFER_TOHOST,   "READ BLOCK LIMITS", SCSI_DONT_EMULATE}, \
   {0x06,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_INIT_ELEMENT_STATUS, SCSI_XFER_AUTO,  NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ6,            SCSI_XFER_TOHOST,   "READ(6)", SCSI_EMULATE}, \
   {0x09,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE6,           SCSI_XFER_TODEVICE, "WRITE(6)", SCSI_EMULATE}, \
   {SCSI_CMD_SLEW_AND_PRINT,   SCSI_XFER_TODEVICE, NULL, SCSI_DONT_EMULATE}, \
   {0x0c,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x0d,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x0e,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_REVERSE,     SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SYNC_BUFFER,      SCSI_XFER_NONE,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SPACE,            SCSI_XFER_NONE,     "SPACE", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_INQUIRY,          SCSI_XFER_TOHOST,   "INQUIRY", SCSI_EMULATE}, \
   {0x13,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_RECOVER_BUFFERED, SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_MODE_SELECT,      SCSI_XFER_TODEVICE, "MODE SELECT(6)", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_RESERVE_UNIT,     SCSI_XFER_NONE,     "RESERVE(6)", SCSI_EMULATE}, \
   {SCSI_CMD_RELEASE_UNIT,     SCSI_XFER_NONE,     "RELEASE(6)", SCSI_EMULATE}, \
   {SCSI_CMD_COPY,             SCSI_XFER_AUTO,     "COPY AND VERIFY", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_ERASE,            SCSI_XFER_NONE,     "ERASE", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_MODE_SENSE,       SCSI_XFER_TOHOST,   "MODE SENSE(6)", SCSI_EMULATE}, \
   {SCSI_CMD_SCAN,             SCSI_XFER_TODEVICE, NULL, SCSI_EMULATE}, \
   {SCSI_CMD_RECV_DIAGNOSTIC,  SCSI_XFER_AUTO,     "RECEIVE DIAGNOSTIC RESULTS", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEND_DIAGNOSTIC,  SCSI_XFER_TODEVICE, "SEND DIAGNOSTIC", SCSI_EMULATE}, \
   {SCSI_CMD_MEDIUM_REMOVAL,   SCSI_XFER_NONE,     "LOCK/UNLOCK DOOR", SCSI_DONT_EMULATE_DONT_LOG}, \
   {0x1f,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x20,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x21,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x22,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_FORMAT_CAPACITIES, SCSI_XFER_TOHOST, "READ FORMAT CAPACITIES", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SET_WINDOW,       SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_CAPACITY,    SCSI_XFER_TOHOST,   "READ CAPACITY", SCSI_EMULATE}, \
   {0x26,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x27,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ10,           SCSI_XFER_TOHOST,   "READ(10)", SCSI_EMULATE}, \
   {SCSI_CMD_READ_GENERATION,  SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE10,          SCSI_XFER_TODEVICE, "WRITE(10)", SCSI_EMULATE}, \
   {SCSI_CMD_SEEK10,           SCSI_XFER_NONE,     NULL, SCSI_DONT_EMULATE}, \
   {0x2c,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_UPDATED_BLOCK, SCSI_XFER_AUTO,   NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE_VERIFY,     SCSI_XFER_AUTO,     "WRITE VERIFY", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_VERIFY,           SCSI_XFER_NONE,     "VERIFY", SCSI_EMULATE}, \
   {SCSI_CMD_SEARCH_DATA_HIGH, SCSI_XFER_AUTO,     "SEARCH HIGH", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEARCH_DATA_EQUAL, SCSI_XFER_AUTO,     "SEARCH EQUAL", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEARCH_DATA_LOW,  SCSI_XFER_AUTO,     "SEARCH LOW", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SET_LIMITS,       SCSI_XFER_AUTO,     "SET LIMITS", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_POSITION,    SCSI_XFER_TOHOST,   NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SYNC_CACHE,       SCSI_XFER_NONE,     "SYNC CACHE", SCSI_EMULATE}, \
   {SCSI_CMD_LOCKUNLOCK_CACHE, SCSI_XFER_AUTO,     "LOCK/UNLOCK CACHE", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_DEFECT_DATA, SCSI_XFER_AUTO,     "READ DEFECT DATA", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_MEDIUM_SCAN,      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_COMPARE,          SCSI_XFER_AUTO,     "COMPARE", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_COPY_VERIFY,      SCSI_XFER_AUTO,     "COPY AND VERIFY", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE_BUFFER,     SCSI_XFER_AUTO,     "WRITE BUFFER", SCSI_DONT_EMULATE_DONT_LOG}, \
   {SCSI_CMD_READ_BUFFER,      SCSI_XFER_AUTO,     "READ BUFFER", SCSI_DONT_EMULATE_DONT_LOG}, \
   {SCSI_CMD_UPDATE_BLOCK,     SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_LONG,        SCSI_XFER_AUTO,     "READ LONG", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE_LONG,       SCSI_XFER_AUTO,     "WRITE LONG", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_CHANGE_DEF,       SCSI_XFER_NONE,     "CHANGE DEFINITION", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE_SAME,       SCSI_XFER_AUTO,     "WRITE SAME", SCSI_EMULATE}, \
   {0x42,                      SCSI_XFER_TODEVICE, "UNMAP/READ SUBCHANNEL", SCSI_EMULATE}, \
   {SCSI_CMD_READ_TOC,         SCSI_XFER_TOHOST,   "READ TOC", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_HEADER,      SCSI_XFER_TOHOST,   "READ HEADER", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_AUDIO10,     SCSI_XFER_NONE,     "PLAY AUDIO(10)", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_GET_CONFIGURATION, SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_AUDIO_MSF,   SCSI_XFER_NONE,     "PLAY AUDIO MSF", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_AUDIO_TRACK, SCSI_XFER_AUTO,     "PLAY AUDIO TRACK", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_AUDIO_RELATIVE, SCSI_XFER_AUTO,  "PLAY AUDIO RELATIVE", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_GET_EVENT_STATUS_NOTIFICATION,	SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PAUSE,            SCSI_XFER_NONE,     "PAUSE/RESUME", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_LOG_SELECT,       SCSI_XFER_TODEVICE, "LOG SELECT", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_LOG_SENSE,        SCSI_XFER_TOHOST,   "LOG SENSE", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_STOP_PLAY,        SCSI_XFER_NONE,     "STOP PLAY", SCSI_DONT_EMULATE}, \
   {0x4f,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x50,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_DISC_INFO,   SCSI_XFER_TOHOST,   "CDR INFO", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_TRACK_INFO,  SCSI_XFER_TOHOST,   "TRACK INFO", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_RESERVE_TRACK,    SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x54,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_MODE_SELECT10,    SCSI_XFER_TODEVICE, "MODE SELECT(10)", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_RESERVE_UNIT10,   SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_RELEASE_UNIT10,   SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x58,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x59,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_MODE_SENSE10,     SCSI_XFER_TOHOST,   "MODE SENSE(10)", SCSI_EMULATE}, \
   {SCSI_CMD_CLOSE_SESSION,    SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_BUFFER_CAPACITY, SCSI_XFER_AUTO, NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEND_CUE_SHEET,   SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PERSISTENT_RESERVE_IN, SCSI_XFER_TOHOST,     "PERSISTENT RESERVE IN", SCSI_EMULATE}, \
   {SCSI_CMD_PERSISTENT_RESERVE_OUT, SCSI_XFER_TODEVICE,     "PERSISTENT RESERVE OUT", SCSI_EMULATE}, \
   {0x60,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x61,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x62,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x63,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x64,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x65,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x66,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x67,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x68,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x69,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x6a,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x6b,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x6c,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x6d,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x6e,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x6f,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x70,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x71,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x72,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x73,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x74,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x75,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x76,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x77,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x78,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x79,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x7a,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x7b,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x7c,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x7d,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x7e,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x7f,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x80,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x81,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x82,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x83,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x84,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x85,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x86,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x87,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ16,           SCSI_XFER_TOHOST,   "READ(16)", SCSI_EMULATE}, \
   {0x89,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE16,          SCSI_XFER_TODEVICE, "WRITE(16)", SCSI_EMULATE}, \
   {0x8b,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x8c,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x8d,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x8e,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_VERIFY16,         SCSI_XFER_NONE,     "VERIFY(16)", SCSI_EMULATE}, \
   {0x90,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x91,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x92,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE_SAME16,     SCSI_XFER_AUTO,     NULL, SCSI_EMULATE}, \
   {0x94,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x95,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x96,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x97,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x98,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x99,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x9a,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x9b,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x9c,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0x9d,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SERVICE_ACTION_IN,SCSI_XFER_TOHOST,   "READ CAPACITY 16", SCSI_EMULATE}, \
   {0x9f,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_REPORT_LUNS,      SCSI_XFER_AUTO,     "REPORT LUNS", SCSI_EMULATE}, \
   {SCSI_CMD_BLANK,            SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xa2,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEND_KEY,         SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_REPORT_KEY,       SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_AUDIO12,     SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_LOADCD,           SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xa7,                      SCSI_XFER_AUTO,     "MOVE MEDIUM", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ12,           SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_TRACK_RELATIVE, SCSI_XFER_AUTO,  NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE12,          SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xab,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_ERASE12,          SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_DVD_STRUCTURE, SCSI_XFER_AUTO,   NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_WRITE_VERIFY12,   SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_VERIFY12,         SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEARCH_DATA_HIGH12, SCSI_XFER_AUTO,   NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEARCH_DATA_EQUAL12, SCSI_XFER_AUTO,  NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEARCH_DATA_LOW12, SCSI_XFER_AUTO,    NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SET_LIMITS12,     SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xb4,                      SCSI_XFER_AUTO,     "READ ELEMENT STATUS", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_REQUEST_VOLUME_ELEMENT_ADDR, SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SET_STREAMING,    SCSI_XFER_TODEVICE, "SET STREAMING", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_DEFECT_DATA12, SCSI_XFER_AUTO,   NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SELECT_CDROM_SPEED, SCSI_XFER_AUTO,   NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_CD_MSF,      SCSI_XFER_TOHOST,   "READ CD MSF", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_AUDIO_SCAN,       SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SET_CDROM_SPEED,  SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_PLAY_CD,          SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {SCSI_CMD_MECH_STATUS,      SCSI_XFER_TOHOST,   "MECHANISM STATUS", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_READ_CD,          SCSI_XFER_TOHOST,   "READ CD", SCSI_DONT_EMULATE}, \
   {SCSI_CMD_SEND_DVD_STRUCTURE, SCSI_XFER_AUTO,   NULL, SCSI_DONT_EMULATE}, \
   {0xc0,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc1,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc2,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc3,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc4,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc5,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc6,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc7,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc8,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xc9,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xca,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xcb,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xcc,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xcd,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xce,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xcf,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd0,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd1,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd2,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd3,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd4,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd5,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd6,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd7,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd8,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xd9,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xda,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xdb,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xdc,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xdd,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xde,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xdf,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe0,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe1,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe2,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe3,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe4,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe5,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe6,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe7,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe8,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xe9,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xea,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xeb,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xec,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xed,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xee,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xef,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf0,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf1,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf2,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf3,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf4,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf5,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf6,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf7,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf8,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xf9,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xfa,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xfb,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xfc,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xfd,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xfe,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE}, \
   {0xff,                      SCSI_XFER_AUTO,     NULL, SCSI_DONT_EMULATE},

#endif
